import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import {
  SEATS,
  attemptMove,
  groundHeightAt,
  interactPoint,
  seatCam,
  sitPose,
  standSpot,
} from "../lib/layout";
import { input, useStore } from "../store";
import type { PromptInfo } from "../store";
import { tagTexture } from "../lib/textures";

const SPEED = 2.5;
const WALK_FREQ = 9;

function approachAngle(a: number, b: number, k: number): number {
  let d = ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
  return a + d * k;
}

export function Player() {
  const name = useStore((s) => s.name);
  const group = useRef<THREE.Group>(null);
  const body = useRef<THREE.Group>(null);
  const legL = useRef<THREE.Group>(null);
  const legR = useRef<THREE.Group>(null);
  const armL = useRef<THREE.Group>(null);
  const armR = useRef<THREE.Group>(null);

  const pos = useRef(new THREE.Vector3(0, 0, -2.3));
  const yaw = useRef(Math.PI);
  const ground = useRef(0);
  const camYaw = useRef(Math.PI);
  const camPos = useRef(new THREE.Vector3(0, 2.05, 1.35));
  const camLook = useRef(new THREE.Vector3(0, 1.45, -3));
  const walkT = useRef(0);
  const sitBlend = useRef(0);
  const moving = useRef(false);
  const prevSeated = useRef<number | null>(null);
  const lastPrompt = useRef<PromptInfo | null>(null);
  const keys = useRef<Set<string>>(new Set());
  const tag = useMemo(() => tagTexture(name || "You"), [name]);

  /* keyboard */
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      keys.current.add(k);
      if (k === "e" || k === "enter") {
        const st = useStore.getState();
        if (st.sitMode) st.stand();
        else if (st.prompt && st.prompt.kind === "sit") st.sit(st.prompt.seatId);
      }
      if (k === "escape") {
        const st = useStore.getState();
        if (st.sitMode) st.stand();
      }
    };
    const up = (e: KeyboardEvent) => keys.current.delete(e.key.toLowerCase());
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const st = useStore.getState();
    const g = group.current;
    if (!g) return;

    /* ---------- movement / sitting ---------- */
    if (st.sitMode && st.seated != null) {
      const seat = SEATS[st.seated];
      const tp = sitPose(seat);
      pos.current.lerp(tp.pos, 1 - Math.exp(-dt * 5.5));
      yaw.current = approachAngle(yaw.current, tp.yaw, 1 - Math.exp(-dt * 7));
      sitBlend.current = Math.min(1, sitBlend.current + dt * 3.4);
      moving.current = false;
    } else {
      if (prevSeated.current != null) {
        /* just stood up — step out in front of the seat */
        const sp = standSpot(SEATS[prevSeated.current]);
        pos.current.set(sp.x, sp.y, sp.z);
        ground.current = sp.y;
        yaw.current = Math.PI;
        prevSeated.current = null;
      }
      sitBlend.current = Math.max(0, sitBlend.current - dt * 3.4);

      let ix = 0;
      let iz = 0;
      const k = keys.current;
      if (k.has("w") || k.has("arrowup")) iz += 1;
      if (k.has("s") || k.has("arrowdown")) iz -= 1;
      if (k.has("a") || k.has("arrowleft")) ix -= 1;
      if (k.has("d") || k.has("arrowright")) ix += 1;
      ix += input.x;
      iz += input.y;
      const len = Math.hypot(ix, iz);

      if (len > 0.04 && !k.has("shift")) {
        const fwd = new THREE.Vector3().subVectors(camLook.current, camPos.current);
        fwd.y = 0;
        fwd.normalize();
        const right = new THREE.Vector3(-fwd.z, 0, fwd.x);
        const mv = new THREE.Vector3()
          .addScaledVector(fwd, iz)
          .addScaledVector(right, ix);
        mv.normalize().multiplyScalar(Math.min(len, 1) * SPEED * dt);
        const res = attemptMove(pos.current.x, pos.current.z, mv.x, mv.z, ground.current);
        pos.current.x = res.x;
        pos.current.z = res.z;
        const gh = groundHeightAt(res.x, res.z);
        ground.current += (gh - ground.current) * Math.min(1, dt * 10);
        pos.current.y = ground.current;
        yaw.current = approachAngle(yaw.current, Math.atan2(mv.x, mv.z), 1 - Math.exp(-dt * 11));
        moving.current = true;
        walkT.current += dt * WALK_FREQ;
      } else {
        moving.current = false;
      }
      if (!st.sitMode) pos.current.y = ground.current;
    }
    prevSeated.current = st.seated;

    /* ---------- apply transform + pose ---------- */
    g.position.copy(pos.current);
    g.rotation.y = yaw.current;
    const bl = sitBlend.current;
    const walk = moving.current ? Math.sin(walkT.current) : 0;
    const idleBob = !moving.current && bl < 0.5 ? Math.sin(state.clock.elapsedTime * 2.2) * 0.012 : 0;
    if (body.current) {
      body.current.position.y = idleBob;
      body.current.rotation.x = -0.1 * bl;
    }
    const swing = 0.55 * walk * (1 - bl);
    if (legL.current) legL.current.rotation.x = -1.48 * bl + swing;
    if (legR.current) legR.current.rotation.x = -1.48 * bl - swing;
    if (armL.current) armL.current.rotation.x = -0.5 * bl - 0.42 * walk * (1 - bl);
    if (armR.current) armR.current.rotation.x = -0.5 * bl + 0.42 * walk * (1 - bl);

    /* ---------- camera ---------- */
    let desPos: THREE.Vector3;
    let desLook: THREE.Vector3;
    let rate: number;
    if (st.sitMode && st.seated != null) {
      const sv = seatCam(SEATS[st.seated]);
      desPos = sv.pos;
      desLook = sv.look;
      rate = 2.6;
    } else {
      if (moving.current) {
        camYaw.current = approachAngle(camYaw.current, yaw.current, 1 - Math.exp(-dt * 2.3));
      }
      const f = new THREE.Vector3(Math.sin(camYaw.current), 0, Math.cos(camYaw.current));
      desPos = new THREE.Vector3().copy(pos.current).addScaledVector(f, -3.35);
      desPos.y = pos.current.y + 1.92;
      desLook = new THREE.Vector3().copy(pos.current).addScaledVector(f, 0.4);
      desLook.y = pos.current.y + 1.42;
      /* keep the camera inside the room (or hallway) */
      if (pos.current.x > 4.4) {
        desPos.x = THREE.MathUtils.clamp(desPos.x, 4.55, 6.75);
        desPos.z = THREE.MathUtils.clamp(desPos.z, 2.4, 3.8);
        desPos.y = THREE.MathUtils.clamp(desPos.y, 0.5, 2.05);
      } else {
        desPos.x = THREE.MathUtils.clamp(desPos.x, -3.98, 3.98);
        desPos.z = THREE.MathUtils.clamp(desPos.z, -3.45, 3.45);
        desPos.y = THREE.MathUtils.clamp(desPos.y, 0.5, 2.9);
      }
      rate = 4.4;
    }
    const kPos = 1 - Math.exp(-dt * rate);
    camPos.current.lerp(desPos, kPos);
    camLook.current.lerp(desLook, kPos);
    state.camera.position.copy(camPos.current);
    state.camera.lookAt(camLook.current);

    /* ---------- interaction prompt ---------- */
    let np: PromptInfo | null = null;
    if (!st.sitMode) {
      let best: { id: number; d2: number } | null = null;
      for (const s of SEATS) {
        const ip = interactPoint(s);
        const dx = pos.current.x - ip.x;
        const dz = pos.current.z - ip.z;
        const d2 = dx * dx + dz * dz;
        if (Math.abs(pos.current.y - s.platformH) > 0.35) continue;
        if (!best || d2 < best.d2) best = { id: s.id, d2 };
      }
      if (best && best.d2 < 1.15 * 1.15) np = { kind: "sit", seatId: best.id };
    } else if (st.seated != null) {
      np = { kind: "stand", seatId: st.seated };
    }
    const lp = lastPrompt.current;
    if ((lp?.kind ?? null) !== (np?.kind ?? null) || lp?.seatId !== np?.seatId) {
      lastPrompt.current = np;
      st.setPrompt(np);
    }
  });

  return (
    <group ref={group} position={[0, 0, -2.3]} rotation-y={Math.PI}>
      <group ref={body}>
        {/* legs — pivot at hips */}
        <group ref={legL} position={[-0.11, 0.8, 0]}>
          <mesh position={[0, -0.39, 0]} castShadow>
            <boxGeometry args={[0.145, 0.78, 0.17]} />
            <meshStandardMaterial color="#2c313c" roughness={0.85} />
          </mesh>
          <mesh position={[0, -0.75, 0.02]} castShadow>
            <boxGeometry args={[0.15, 0.08, 0.24]} />
            <meshStandardMaterial color="#17181d" roughness={0.7} />
          </mesh>
        </group>
        <group ref={legR} position={[0.11, 0.8, 0]}>
          <mesh position={[0, -0.39, 0]} castShadow>
            <boxGeometry args={[0.145, 0.78, 0.17]} />
            <meshStandardMaterial color="#2c313c" roughness={0.85} />
          </mesh>
          <mesh position={[0, -0.75, 0.02]} castShadow>
            <boxGeometry args={[0.15, 0.08, 0.24]} />
            <meshStandardMaterial color="#17181d" roughness={0.7} />
          </mesh>
        </group>
        {/* torso */}
        <mesh position={[0, 1.06, 0]} castShadow>
          <boxGeometry args={[0.42, 0.52, 0.24]} />
          <meshStandardMaterial color="#454b57" roughness={0.8} />
        </mesh>
        <mesh position={[0, 0.82, 0]}>
          <boxGeometry args={[0.44, 0.06, 0.26]} />
          <meshStandardMaterial color="#23262d" roughness={0.7} />
        </mesh>
        <mesh position={[0, 1.22, 0.07]}>
          <boxGeometry args={[0.3, 0.14, 0.05]} />
          <meshStandardMaterial color="#333944" roughness={0.8} />
        </mesh>
        {/* arms — pivot at shoulders */}
        <group ref={armL} position={[-0.27, 1.3, 0]}>
          <mesh position={[0, -0.22, 0]} castShadow>
            <boxGeometry args={[0.11, 0.48, 0.14]} />
            <meshStandardMaterial color="#454b57" roughness={0.8} />
          </mesh>
          <mesh position={[0, -0.46, 0]}>
            <boxGeometry args={[0.1, 0.1, 0.13]} />
            <meshStandardMaterial color="#e6b48c" roughness={0.8} />
          </mesh>
        </group>
        <group ref={armR} position={[0.27, 1.3, 0]}>
          <mesh position={[0, -0.22, 0]} castShadow>
            <boxGeometry args={[0.11, 0.48, 0.14]} />
            <meshStandardMaterial color="#454b57" roughness={0.8} />
          </mesh>
          <mesh position={[0, -0.46, 0]}>
            <boxGeometry args={[0.1, 0.1, 0.13]} />
            <meshStandardMaterial color="#e6b48c" roughness={0.8} />
          </mesh>
        </group>
        {/* head */}
        <mesh position={[0, 1.5, 0]} castShadow>
          <boxGeometry args={[0.275, 0.275, 0.275]} />
          <meshStandardMaterial color="#e6b48c" roughness={0.75} />
        </mesh>
        <mesh position={[0, 1.63, 0]}>
          <boxGeometry args={[0.29, 0.075, 0.29]} />
          <meshStandardMaterial color="#241a12" roughness={0.9} />
        </mesh>
        {[-0.062, 0.062].map((x) => (
          <mesh key={x} position={[x, 1.52, 0.14]}>
            <boxGeometry args={[0.042, 0.05, 0.012]} />
            <meshStandardMaterial color="#191a20" roughness={0.4} />
          </mesh>
        ))}
        {/* name tag */}
        <sprite position={[0, 1.95, 0]} scale={[0.95, 0.36, 1]}>
          <spriteMaterial map={tag} transparent depthWrite={false} opacity={0.95} />
        </sprite>
      </group>
    </group>
  );
}
