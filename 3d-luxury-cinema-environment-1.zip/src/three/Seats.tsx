import { useMemo } from "react";
import * as THREE from "three";
import { RoundedBox } from "@react-three/drei";
import { PLATFORM, SEATS } from "../lib/layout";
import type { SeatDef } from "../lib/layout";
import { carpetTexture, fabricTexture, glowTexture, seatNumberTexture } from "../lib/textures";

function Glow({
  pos,
  scale = 1.8,
  color = "#ff9a3c",
  opacity = 0.16,
}: {
  pos: [number, number, number];
  scale?: number;
  color?: string;
  opacity?: number;
}) {
  const map = useMemo(() => glowTexture(), []);
  return (
    <sprite position={pos} scale={[scale, scale, 1]}>
      <spriteMaterial
        map={map}
        color={color}
        transparent
        opacity={opacity}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </sprite>
  );
}

function Seat({ def }: { def: SeatDef }) {
  const fabric = useMemo(() => fabricTexture(), []);
  const badge = useMemo(() => seatNumberTexture(def.id), [def.id]);
  const dark = "#170a10";
  return (
    <group position={[def.x, def.platformH, def.z]} rotation-y={Math.PI}>
      {/* base */}
      <mesh position={[0, 0.16, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.92, 0.32, 0.82]} />
        <meshStandardMaterial map={fabric} roughness={0.95} />
      </mesh>
      {/* seat cushion */}
      <RoundedBox args={[0.8, 0.17, 0.72]} radius={0.05} smoothness={2} position={[0, 0.4, 0.03]} castShadow>
        <meshStandardMaterial map={fabric} roughness={0.92} />
      </RoundedBox>
      {/* backrest (tilted) */}
      <group position={[0, 0.44, -0.3]} rotation-x={-0.15}>
        <RoundedBox args={[0.92, 0.9, 0.22]} radius={0.05} smoothness={2} position={[0, 0.45, 0]} castShadow>
          <meshStandardMaterial map={fabric} roughness={0.95} />
        </RoundedBox>
        <RoundedBox args={[0.6, 0.34, 0.2]} radius={0.06} smoothness={2} position={[0, 1.02, -0.015]} castShadow>
          <meshStandardMaterial map={fabric} roughness={0.95} />
        </RoundedBox>
        {/* seat number badge on the rear */}
        <mesh position={[0, 0.9, -0.125]} rotation={[Math.PI, 0, 0]}>
          <planeGeometry args={[0.19, 0.095]} />
          <meshBasicMaterial map={badge} transparent depthWrite={false} />
        </mesh>
      </group>
      {/* armrests */}
      {[-0.39, 0.39].map((x) => (
        <group key={x}>
          <RoundedBox args={[0.17, 0.46, 0.85]} radius={0.045} smoothness={2} position={[x, 0.55, 0.0]} castShadow>
            <meshStandardMaterial map={fabric} roughness={0.95} />
          </RoundedBox>
          <mesh position={[x, 0.79, 0.1]}>
            <boxGeometry args={[0.15, 0.045, 0.52]} />
            <meshStandardMaterial color={dark} roughness={0.85} />
          </mesh>
        </group>
      ))}
      {/* cup holder on right arm */}
      <mesh position={[0.39, 0.83, -0.18]}>
        <cylinderGeometry args={[0.055, 0.055, 0.028, 16]} />
        <meshStandardMaterial color="#9aa1ad" roughness={0.22} metalness={0.95} />
      </mesh>
      <mesh position={[0.39, 0.83, -0.18]}>
        <cylinderGeometry args={[0.043, 0.043, 0.032, 16]} />
        <meshStandardMaterial color="#0b0b0d" roughness={0.6} />
      </mesh>
      {/* seat base LED (front) */}
      <mesh position={[0, 0.03, 0.39]}>
        <boxGeometry args={[0.72, 0.016, 0.016]} />
        <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={1.5} />
      </mesh>
      <Glow pos={[0, 0.06, 0.45]} scale={0.55} opacity={0.1} />
    </group>
  );
}

export function SeatsBlock() {
  const carpet = useMemo(() => carpetTexture(6, 4), []);
  const stepMat = { color: "#17181d", roughness: 0.95 } as const;
  const led = (int = 2.0) => (
    <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={int} />
  );

  const stepGlows: Array<[number, number, number]> = [
    [3.32, 0.22, 1.0],
    [3.32, 0.22, 2.05],
    [3.32, 0.22, 3.1],
    [-3.32, 0.22, 1.0],
    [-3.32, 0.22, 2.05],
    [-3.32, 0.22, 3.1],
    [0, 0.5, 0.42],
    [-1.6, 0.5, 0.42],
    [1.6, 0.5, 0.42],
    [-0.8, 0.5, 0.42],
    [0.8, 0.5, 0.42],
  ];

  return (
    <group>
      {/* ---- raised platform ---- */}
      <mesh position={[0, PLATFORM.h / 2, (PLATFORM.z0 + PLATFORM.z1) / 2]} castShadow receiveShadow>
        <boxGeometry args={[PLATFORM.x1 - PLATFORM.x0, PLATFORM.h, PLATFORM.z1 - PLATFORM.z0]} />
        <meshStandardMaterial color="#141419" roughness={0.95} />
      </mesh>
      <mesh position={[0, PLATFORM.h + 0.011, (PLATFORM.z0 + PLATFORM.z1) / 2]} rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[PLATFORM.x1 - PLATFORM.x0, PLATFORM.z1 - PLATFORM.z0]} />
        <meshStandardMaterial map={carpet} roughness={0.97} />
      </mesh>
      {/* amber LED edge along platform front */}
      <mesh position={[0, PLATFORM.h - 0.015, PLATFORM.z0 + 0.012]}>
        <boxGeometry args={[PLATFORM.x1 - PLATFORM.x0, 0.03, 0.03]} />
        {led()}
      </mesh>
      {/* ---- side steps (left + right) ---- */}
      {[
        { s: 1 },
        { s: -1 },
      ].map(({ s }) => (
        <group key={s} rotation-y={s > 0 ? 0 : Math.PI}>
          {/* step 1 (lower, outer) */}
          <mesh position={[3.25, 0.07, 2.05]} castShadow receiveShadow>
            <boxGeometry args={[0.3, 0.14, 3.5]} />
            <meshStandardMaterial {...stepMat} />
          </mesh>
          {/* step 2 (upper, inner) */}
          <mesh position={[2.95, 0.14, 2.05]} castShadow receiveShadow>
            <boxGeometry args={[0.3, 0.28, 3.5]} />
            <meshStandardMaterial {...stepMat} />
          </mesh>
          {/* LED strips on step noses */}
          <mesh position={[3.39, 0.065, 2.05]}>
            <boxGeometry args={[0.02, 0.125, 3.48]} />
            {led(1.7)}
          </mesh>
          <mesh position={[3.09, 0.135, 2.05]}>
            <boxGeometry args={[0.02, 0.255, 3.48]} />
            {led(1.9)}
          </mesh>
          <mesh position={[2.79, 0.2, 2.05]}>
            <boxGeometry args={[0.02, 0.38, 3.48]} />
            {led(2.1)}
          </mesh>
        </group>
      ))}
      {/* amber sprite glows along steps + platform edge */}
      {stepGlows.map((p, i) => (
        <Glow key={i} pos={p} scale={1.05} opacity={0.22} />
      ))}

      {/* ---- exactly 10 seats ---- */}
      {SEATS.map((s) => (
        <Seat key={s.id} def={s} />
      ))}
    </group>
  );
}
