import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SCREEN } from "../lib/layout";
import {
  woodTexture,
  fabricTexture,
  screenIdleTexture,
  glowTexture,
} from "../lib/textures";
import { useStore } from "../store";

const SC = SCREEN;
const SCREEN_CY = SC.bottomY + SC.h / 2;

function Glow({
  pos,
  scale = 1.8,
  color = "#ff9a3c",
  opacity = 0.16,
}: {
  pos: [number, number, number];
  scale?: number;
  color?: string;
  opacity?: number;
}) {
  const map = useMemo(() => glowTexture(), []);
  return (
    <sprite position={pos} scale={[scale, scale, 1]}>
      <spriteMaterial
        map={map}
        color={color}
        transparent
        opacity={opacity}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </sprite>
  );
}

export function ScreenBlock() {
  const playing = useStore((s) => s.playing);
  const idle = useMemo(() => screenIdleTexture(), []);
  const wood = useMemo(() => woodTexture(3, 1), []);
  const fabric = useMemo(() => fabricTexture(), []);
  const screenMat = useRef<THREE.MeshStandardMaterial>(null);

  useFrame(({ clock }) => {
    if (screenMat.current) {
      screenMat.current.emissiveIntensity = playing
        ? 0.22
        : 0.5 + Math.sin(clock.elapsedTime * 0.7) * 0.045;
    }
  });

  const frame = 0.28;
  const fw = SC.w + frame * 2;
  const fh = SC.h + frame * 2;
  const fz = -3.845;

  return (
    <group>
      {/* ---- architectural recess ---- */}
      <mesh position={[0, SCREEN_CY, -4.19]}>
        <boxGeometry args={[4.32, 2.78, 0.06]} />
        <meshStandardMaterial color="#060608" roughness={0.95} />
      </mesh>
      <mesh position={[0, 2.99, -4.0]}>
        <boxGeometry args={[4.32, 0.06, 0.44]} />
        <meshStandardMaterial color="#070708" roughness={0.95} />
      </mesh>
      <mesh position={[0, 0.27, -4.0]}>
        <boxGeometry args={[4.32, 0.06, 0.44]} />
        <meshStandardMaterial color="#070708" roughness={0.95} />
      </mesh>
      {[-2.13, 2.13].map((x) => (
        <mesh key={x} position={[x, SCREEN_CY, -4.0]}>
          <boxGeometry args={[0.06, 2.78, 0.44]} />
          <meshStandardMaterial color="#070708" roughness={0.95} />
        </mesh>
      ))}

      {/* ---- amber backlight inside recess ---- */}
      <mesh position={[0, SC.bottomY + SC.h + 0.02, -4.14]}>
        <boxGeometry args={[3.75, 0.028, 0.028]} />
        <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={2.6} />
      </mesh>
      <mesh position={[0, SC.bottomY - 0.02, -4.14]}>
        <boxGeometry args={[3.75, 0.028, 0.028]} />
        <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={2.6} />
      </mesh>
      {[-(SC.w / 2 + 0.02), SC.w / 2 + 0.02].map((x) => (
        <mesh key={x} position={[x, SCREEN_CY, -4.14]}>
          <boxGeometry args={[0.028, 2.08, 0.028]} />
          <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={2.6} />
        </mesh>
      ))}
      {[
        [-1.85, 2.5],
        [1.85, 2.5],
        [-1.85, 0.78],
        [1.85, 0.78],
      ].map((p, i) => (
        <Glow key={i} pos={[p[0], p[1], -4.02]} scale={2.5} opacity={0.3} />
      ))}

      {/* ---- the screen (video surface maps here via DOM overlay) ---- */}
      <mesh position={[0, SCREEN_CY, SC.z]}>
        <planeGeometry args={[SC.w, SC.h]} />
        <meshStandardMaterial
          ref={screenMat}
          map={idle}
          emissiveMap={idle}
          emissive="#9aa6ba"
          emissiveIntensity={0.5}
          color="#05070c"
          roughness={0.32}
          metalness={0.1}
        />
      </mesh>

      {/* ---- thick dark frame ---- */}
      <mesh position={[-(SC.w / 2 + frame / 2), SCREEN_CY, fz]}>
        <boxGeometry args={[frame, fh, 0.14]} />
        <meshStandardMaterial color="#0e0e12" roughness={0.45} metalness={0.12} />
      </mesh>
      <mesh position={[SC.w / 2 + frame / 2, SCREEN_CY, fz]}>
        <boxGeometry args={[frame, fh, 0.14]} />
        <meshStandardMaterial color="#0e0e12" roughness={0.45} metalness={0.12} />
      </mesh>
      <mesh position={[0, SC.bottomY + SC.h + frame / 2, fz]}>
        <boxGeometry args={[fw, frame, 0.14]} />
        <meshStandardMaterial color="#0e0e12" roughness={0.45} metalness={0.12} />
      </mesh>
      <mesh position={[0, SC.bottomY - frame / 2, fz]}>
        <boxGeometry args={[fw, frame, 0.14]} />
        <meshStandardMaterial color="#0e0e12" roughness={0.45} metalness={0.12} />
      </mesh>
      {/* metal edge trim on frame */}
      <mesh position={[0, SC.bottomY - frame - 0.016, fz]}>
        <boxGeometry args={[fw + 0.06, 0.02, 0.15]} />
        <meshStandardMaterial color="#454a53" roughness={0.28} metalness={0.9} />
      </mesh>
      <mesh position={[0, SC.bottomY + SC.h + frame + 0.016, fz]}>
        <boxGeometry args={[fw + 0.06, 0.02, 0.15]} />
        <meshStandardMaterial color="#454a53" roughness={0.28} metalness={0.9} />
      </mesh>
      {/* inner bezel lip */}
      {[
        [-(SC.w / 2 + 0.02), SCREEN_CY, 0.05, fh - 0.1],
        [SC.w / 2 + 0.02, SCREEN_CY, 0.05, fh - 0.1],
      ].map((p, i) => (
        <mesh key={i} position={[p[0], p[1], -3.9]}>
          <boxGeometry args={[p[2], p[3], 0.03]} />
          <meshStandardMaterial color="#050506" roughness={0.6} />
        </mesh>
      ))}

      {/* ---- media console ---- */}
      <group position={[0, 0, -3.56]}>
        <mesh position={[0, 0.25, 0]} castShadow>
          <boxGeometry args={[3.8, 0.5, 0.44]} />
          <meshStandardMaterial map={wood} color="#8a7a6a" roughness={0.55} />
        </mesh>
        <mesh position={[0, 0.525, 0]}>
          <boxGeometry args={[3.92, 0.045, 0.5]} />
          <meshStandardMaterial map={wood} roughness={0.4} />
        </mesh>
        <mesh position={[0, 0.26, 0.225]}>
          <boxGeometry args={[3.55, 0.36, 0.015]} />
          <meshStandardMaterial
            color="#0a0c10"
            transparent
            opacity={0.4}
            roughness={0.1}
            metalness={0.2}
          />
        </mesh>
        <mesh position={[0, 0.5, 0.24]}>
          <boxGeometry args={[3.62, 0.018, 0.018]} />
          <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={2.1} />
        </mesh>
        {[-1.78, 1.78].map((x) => (
          <mesh key={x} position={[x, 0.02, 0]}>
            <boxGeometry args={[0.06, 0.05, 0.4]} />
            <meshStandardMaterial color="#191a1e" roughness={0.4} metalness={0.6} />
          </mesh>
        ))}
        {/* popcorn */}
        <group position={[1.35, 0.55, 0]}>
          <mesh position={[0, 0.09, 0]} castShadow>
            <cylinderGeometry args={[0.105, 0.085, 0.18, 14]} />
            <meshStandardMaterial color="#8e1d18" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.16, 0]}>
            <cylinderGeometry args={[0.108, 0.108, 0.035, 14]} />
            <meshStandardMaterial color="#efe6da" roughness={0.7} />
          </mesh>
          {[
            [0.03, 0.2, 0.02],
            [-0.04, 0.21, -0.02],
            [0.01, 0.23, -0.04],
            [-0.02, 0.2, 0.05],
            [0.05, 0.22, -0.01],
            [-0.05, 0.23, 0.03],
            [0, 0.25, 0.01],
          ].map((p, i) => (
            <mesh key={i} position={[p[0], p[1], p[2]]} castShadow>
              <sphereGeometry args={[0.026, 6, 5]} />
              <meshStandardMaterial color="#f2c94c" roughness={0.8} />
            </mesh>
          ))}
        </group>
        {/* remotes + cup */}
        <mesh position={[-0.9, 0.575, 0.05]} rotation-x={-0.3}>
          <boxGeometry args={[0.05, 0.012, 0.16]} />
          <meshStandardMaterial color="#101216" roughness={0.4} />
        </mesh>
        <mesh position={[-0.62, 0.575, 0.08]} rotation-x={-0.3}>
          <boxGeometry args={[0.05, 0.012, 0.16]} />
          <meshStandardMaterial color="#16181d" roughness={0.4} />
        </mesh>
        <mesh position={[-0.35, 0.6, 0.03]}>
          <cylinderGeometry args={[0.04, 0.034, 0.13, 12]} />
          <meshStandardMaterial color="#17181c" roughness={0.3} metalness={0.3} />
        </mesh>
      </group>

      {/* ---- center speaker ---- */}
      <group position={[0, 0, -3.56]}>
        <mesh position={[0, 0.66, 0]} castShadow>
          <boxGeometry args={[0.64, 0.24, 0.3]} />
          <meshStandardMaterial color="#141416" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.66, 0.155]}>
          <planeGeometry args={[0.56, 0.2]} />
          <meshStandardMaterial map={fabric} color="#888" roughness={0.95} />
        </mesh>
        <mesh position={[0, 0.72, 0.157]} rotation-x={Math.PI / 2}>
          <circleGeometry args={[0.04, 14]} />
          <meshStandardMaterial color="#3a3d44" roughness={0.3} metalness={0.7} />
        </mesh>
      </group>

      {/* ---- tower speakers + sub ---- */}
      {[-2.44, 2.44].map((x) => (
        <group key={x} position={[x, 0, -3.56]}>
          <mesh position={[0, 0.56, 0]} castShadow>
            <boxGeometry args={[0.44, 1.08, 0.36]} />
            <meshStandardMaterial color="#131316" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.58, 0.185]}>
            <planeGeometry args={[0.34, 0.84]} />
            <meshStandardMaterial map={fabric} color="#777" roughness={0.95} />
          </mesh>
          <mesh position={[0, 1.13, 0]}>
            <boxGeometry args={[0.46, 0.022, 0.38]} />
            <meshStandardMaterial color="#454a53" roughness={0.28} metalness={0.9} />
          </mesh>
        </group>
      ))}
      <group position={[-2.98, 0, -3.5]}>
        <mesh position={[0, 0.26, 0]} castShadow>
          <boxGeometry args={[0.46, 0.5, 0.44]} />
          <meshStandardMaterial color="#131316" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.26, 0.225]} rotation-x={Math.PI / 2}>
          <circleGeometry args={[0.15, 18]} />
          <meshStandardMaterial map={fabric} color="#666" roughness={0.95} />
        </mesh>
      </group>

      {/* ---- ambient glow spilling from screen area ---- */}
      <Glow pos={[0, 0.6, -3.25]} scale={3.4} opacity={0.1} />
      <Glow pos={[0, 2.7, -3.3]} scale={2.6} opacity={0.08} />
    </group>
  );
}
