import { Suspense, useMemo } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { CinemaShell } from "./CinemaShell";
import { ScreenBlock } from "./ScreenBlock";
import { SeatsBlock } from "./Seats";
import { Player } from "./Player";
import { shared3d } from "../store";

function CameraProbe() {
  useFrame((s) => {
    shared3d.camera = s.camera;
  });
  return null;
}

function SceneLights() {
  const keyTarget = useMemo(() => new THREE.Object3D(), []);
  const screenTarget = useMemo(() => new THREE.Object3D(), []);
  const seatTarget = useMemo(() => new THREE.Object3D(), []);
  keyTarget.position.set(0, 0.4, -3.2);
  screenTarget.position.set(0, 1.4, -3.9);
  seatTarget.position.set(0, 0.4, 1.2);
  return (
    <group>
      <primitive object={keyTarget} />
      <primitive object={screenTarget} />
      <primitive object={seatTarget} />
      <ambientLight intensity={0.16} color="#4c4136" />
      <hemisphereLight intensity={0.32} color="#2b2218" groundColor="#0b0906" />
      {/* key light over the room, casts shadows */}
      <spotLight
        position={[0, 3.0, 0.4]}
        angle={0.75}
        penumbra={0.9}
        intensity={1.5}
        decay={0}
        distance={0}
        color="#ffd9ae"
        castShadow
        target={keyTarget}
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0004}
      />
      {/* warm wash over the screen */}
      <spotLight
        position={[0, 2.95, -2.2]}
        angle={0.95}
        penumbra={1}
        intensity={0.9}
        decay={0}
        color="#ffca94"
        target={screenTarget}
      />
      {/* soft pool over the seating */}
      <spotLight
        position={[0, 2.92, 0.9]}
        angle={1.0}
        penumbra={1}
        intensity={0.65}
        decay={0}
        color="#ffd2a0"
        target={seatTarget}
      />
      {/* amber accents */}
      <pointLight position={[0, 0.95, -3.15]} intensity={0.5} decay={0} distance={5} color="#ff9a3c" />
      <pointLight position={[0, 0.6, 0.5]} intensity={0.32} decay={0} distance={3} color="#ff9a3c" />
      <pointLight position={[0, 2.3, 3.1]} intensity={0.35} decay={0} distance={6} color="#ffb066" />
      {/* hallway warmth */}
      <pointLight position={[5.7, 1.95, 3.05]} intensity={0.9} decay={0} distance={6} color="#ffb066" />
    </group>
  );
}

export function CinemaSceneView() {
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      camera={{ fov: 58, near: 0.1, far: 60, position: [0, 2.05, 1.35] }}
    >
      <color attach="background" args={["#020203"]} />
      <fog attach="fog" args={["#050403", 11, 32]} />
      <Suspense fallback={null}>
        <SceneLights />
        <CinemaShell />
        <ScreenBlock />
        <SeatsBlock />
        <Player />
        <CameraProbe />
      </Suspense>
    </Canvas>
  );
}
