import { useMemo } from "react";
import * as THREE from "three";
import { useLoader } from "@react-three/fiber";
import { ROOM } from "../lib/layout";
import {
  carpetTexture,
  woodTexture,
  panelTexture,
  velvetTexture,
  glowTexture,
  exitTexture,
  neonTexture,
} from "../lib/textures";

const W = ROOM.W;
const D = ROOM.D;
const H = ROOM.H;

/* ---------------- shared bits ---------------- */

function Glow({
  pos,
  scale = 1.8,
  color = "#ff9a3c",
  opacity = 0.16,
}: {
  pos: [number, number, number];
  scale?: number;
  color?: string;
  opacity?: number;
}) {
  const map = useMemo(() => glowTexture(), []);
  return (
    <sprite position={pos} scale={[scale, scale, 1]}>
      <spriteMaterial
        map={map}
        color={color}
        transparent
        opacity={opacity}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </sprite>
  );
}

function Wood({ w, h, d, pos }: { w: number; h: number; d: number; pos: [number, number, number] }) {
  const map = useMemo(() => woodTexture(2, 1), []);
  return (
    <mesh position={pos} castShadow receiveShadow>
      <boxGeometry args={[w, h, d]} />
      <meshStandardMaterial map={map} roughness={0.5} metalness={0.05} />
    </mesh>
  );
}

function Metal({ w, h, d, pos }: { w: number; h: number; d: number; pos: [number, number, number] }) {
  return (
    <mesh position={pos}>
      <boxGeometry args={[w, h, d]} />
      <meshStandardMaterial color="#3c4046" roughness={0.32} metalness={0.85} />
    </mesh>
  );
}

function AcousticPanel({
  pos,
  size,
}: {
  pos: [number, number, number];
  size: [number, number, number];
}) {
  const map = useMemo(() => panelTexture(), []);
  return (
    <mesh position={pos} receiveShadow>
      <boxGeometry args={size} />
      <meshStandardMaterial map={map} roughness={0.93} metalness={0.02} />
    </mesh>
  );
}

/* ---------------- floor & ceiling ---------------- */

function Floor() {
  const carpet = useMemo(() => carpetTexture(9, 8), []);
  const wood = useMemo(() => woodTexture(4, 2), []);
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[W, D]} />
        <meshStandardMaterial map={carpet} roughness={0.97} />
      </mesh>
      {/* hallway wood floor */}
      <mesh rotation-x={-Math.PI / 2} position={[5.65, 0.006, 3.05]}>
        <planeGeometry args={[2.72, 1.74]} />
        <meshStandardMaterial map={wood} roughness={0.55} />
      </mesh>
      {/* burgundy hallway runner */}
      <mesh rotation-x={-Math.PI / 2} position={[5.6, 0.012, 3.05]}>
        <planeGeometry args={[2.15, 1.2]} />
        <meshStandardMaterial color="#3a1220" roughness={0.95} />
      </mesh>
      {/* door threshold */}
      <mesh position={[4.3, 0.012, 3.05]}>
        <boxGeometry args={[0.18, 0.024, 1.12]} />
        <meshStandardMaterial color="#2c2620" roughness={0.5} metalness={0.4} />
      </mesh>
    </group>
  );
}

function Ceiling() {
  const panelXs = [-2.6, 0, 2.6];
  const panelZs = [-1.85, 1.35];
  return (
    <group>
      {/* main ceiling slab */}
      <mesh rotation-x={Math.PI / 2} position={[0, H, 0]}>
        <planeGeometry args={[W, D]} />
        <meshStandardMaterial color="#0b0a0d" roughness={0.95} />
      </mesh>
      {/* hallway ceiling */}
      <mesh rotation-x={Math.PI / 2} position={[5.65, 2.3, 3.05]}>
        <planeGeometry args={[2.72, 1.74]} />
        <meshStandardMaterial color="#171310" roughness={0.95} />
      </mesh>
      {/* recessed panels with amber edges */}
      {panelZs.map((z) =>
        panelXs.map((x) => (
          <group key={`${x}${z}`}>
            <mesh position={[x, H - 0.03, z]}>
              <boxGeometry args={[2.55, 0.05, 2.05]} />
              <meshStandardMaterial color="#121116" roughness={0.9} />
            </mesh>
            {[
              [x, H - 0.065, z - 1.01, 2.65, 0.04, 0.045],
              [x, H - 0.065, z + 1.01, 2.65, 0.04, 0.045],
              [x - 1.26, H - 0.065, z, 0.045, 0.04, 2.1],
              [x + 1.26, H - 0.065, z, 0.045, 0.04, 2.1],
            ].map((p, i) => (
              <mesh key={i} position={[p[0], p[1], p[2]]}>
                <boxGeometry args={[p[3], p[4], p[5]]} />
                <meshStandardMaterial color="#2a1a0e" emissive="#ff9a3c" emissiveIntensity={1.15} />
              </mesh>
            ))}
            {/* warm downlight */}
            <mesh rotation-x={Math.PI / 2} position={[x, H - 0.075, z]}>
              <circleGeometry args={[0.11, 24]} />
              <meshStandardMaterial color="#3a2c1c" emissive="#ffdcb0" emissiveIntensity={2.6} />
            </mesh>
          </group>
        ))
      )}
      {/* hallway downlights */}
      {[5.3, 6.35].map((x) => (
        <mesh key={x} rotation-x={Math.PI / 2} position={[x, 2.24, 3.05]}>
          <circleGeometry args={[0.09, 20]} />
          <meshStandardMaterial color="#3a2c1c" emissive="#ffdcb0" emissiveIntensity={2.4} />
        </mesh>
      ))}
    </group>
  );
}

function CoveLight() {
  const insets: Array<[number, number, number, number, number, number]> = [
    [0, H - 0.1, -(D / 2) + 0.17, W - 0.34, 0.05, 0.05],
    [0, H - 0.1, D / 2 - 0.17, W - 0.34, 0.05, 0.05],
    [-(W / 2) + 0.17, H - 0.1, 0, 0.05, 0.05, D - 0.34],
    [W / 2 - 0.17, H - 0.1, 0, 0.05, 0.05, D - 0.34],
  ];
  const glows: Array<[number, number, number]> = [];
  [-3.2, -1.6, 0, 1.6, 3.2].forEach((x) => {
    glows.push([x, H - 0.14, -(D / 2) + 0.17], [x, H - 0.14, D / 2 - 0.17]);
  });
  [-2.6, -0.9, 0.8, 2.5].forEach((z) => {
    glows.push([-(W / 2) + 0.17, H - 0.14, z], [W / 2 - 0.17, H - 0.14, z]);
  });
  return (
    <group>
      {insets.map((p, i) => (
        <mesh key={i} position={[p[0], p[1], p[2]]}>
          <boxGeometry args={[p[3], p[4], p[5]]} />
          <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={1.9} />
        </mesh>
      ))}
      {glows.map((p, i) => (
        <Glow key={i} pos={p} scale={2.0} opacity={0.13} />
      ))}
    </group>
  );
}

/* ---------------- wall pieces ---------------- */

function Sconce({ pos, rotY = 0 }: { pos: [number, number, number]; rotY?: number }) {
  return (
    <group position={pos} rotation-y={rotY}>
      <mesh>
        <boxGeometry args={[0.035, 0.36, 0.14]} />
        <meshStandardMaterial color="#232326" roughness={0.4} metalness={0.7} />
      </mesh>
      <mesh position={[0.035, 0, 0]}>
        <boxGeometry args={[0.02, 0.24, 0.08]} />
        <meshStandardMaterial color="#3a2a18" emissive="#ffcf9a" emissiveIntensity={2.6} />
      </mesh>
      <Glow pos={[0.14, 0, 0]} scale={0.8} opacity={0.32} />
    </group>
  );
}

function Poster({
  url,
  pos,
  rotY,
  lit = false,
  size = [0.62, 0.93] as [number, number],
}: {
  url: string;
  pos: [number, number, number];
  rotY: number;
  lit?: boolean;
  size?: [number, number];
}) {
  const map = useLoader(THREE.TextureLoader, url);
  useMemo(() => {
    map.colorSpace = THREE.SRGBColorSpace;
    map.anisotropy = 8;
  }, [map]);
  return (
    <group position={pos} rotation-y={rotY}>
      {/* frame / lightbox */}
      <mesh position={[0, 0, lit ? -0.015 : -0.025]}>
        <boxGeometry args={[size[0] + 0.08, size[1] + 0.1, 0.05]} />
        {lit ? (
          <meshStandardMaterial color="#331f0e" emissive="#ff9a3c" emissiveIntensity={0.7} />
        ) : (
          <meshStandardMaterial color="#15120e" roughness={0.5} metalness={0.15} />
        )}
      </mesh>
      <mesh position={[0, 0, 0.01]}>
        <planeGeometry args={size} />
        <meshStandardMaterial map={map} roughness={0.42} metalness={0.05} />
      </mesh>
      {/* glass sheen */}
      <mesh position={[0, 0, 0.018]}>
        <planeGeometry args={size} />
        <meshStandardMaterial
          color="#aebfd4"
          transparent
          opacity={0.055}
          roughness={0.08}
          metalness={0.4}
        />
      </mesh>
      {lit && <Glow pos={[0, 0, 0.22]} scale={1.7} opacity={0.22} />}
    </group>
  );
}

function Plant({ pos, s = 1 }: { pos: [number, number, number]; s?: number }) {
  const leaves = useMemo(() => {
    const arr: Array<{ p: [number, number, number]; r: number; sc: number }> = [];
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2;
      arr.push({
        p: [Math.cos(a) * 0.14, 0.52 + (i % 4) * 0.14, Math.sin(a) * 0.14],
        r: a,
        sc: 1 + (i % 3) * 0.25,
      });
    }
    return arr;
  }, []);
  return (
    <group position={pos} scale={s}>
      <mesh position={[0, 0.16, 0]} castShadow>
        <cylinderGeometry args={[0.24, 0.19, 0.34, 18]} />
        <meshStandardMaterial color="#201a14" roughness={0.85} />
      </mesh>
      <mesh position={[0, 0.34, 0]} rotation-x={-Math.PI / 2}>
        <circleGeometry args={[0.21, 16]} />
        <meshStandardMaterial color="#171310" roughness={1} />
      </mesh>
      <mesh position={[0, 0.55, 0]}>
        <cylinderGeometry args={[0.016, 0.022, 0.5, 6]} />
        <meshStandardMaterial color="#3a2c1c" roughness={0.9} />
      </mesh>
      {leaves.map((l, i) => (
        <mesh key={i} position={l.p} rotation-y={l.r} rotation-x={-0.55} castShadow>
          <sphereGeometry args={[1, 7, 5]} />
          <meshStandardMaterial
            color={i % 2 ? "#1f3b26" : "#27452d"}
            roughness={0.92}
          />
        </mesh>
      ))}
    </group>
  );
}

/* ---------------- door + hallway ---------------- */

function DoorAndHallway() {
  const doorWood = useMemo(() => woodTexture(1, 1), []);
  return (
    <group>
      {/* door frame jambs + header */}
      <mesh position={[4.3, 1.1, 2.5]}>
        <boxGeometry args={[0.14, 2.24, 0.12]} />
        <meshStandardMaterial color="#2a2a30" roughness={0.35} metalness={0.7} />
      </mesh>
      <mesh position={[4.3, 1.1, 3.6]}>
        <boxGeometry args={[0.14, 2.24, 0.12]} />
        <meshStandardMaterial color="#2a2a30" roughness={0.35} metalness={0.7} />
      </mesh>
      <mesh position={[4.3, 2.2, 3.05]}>
        <boxGeometry args={[0.14, 0.14, 1.24]} />
        <meshStandardMaterial color="#2a2a30" roughness={0.35} metalness={0.7} />
      </mesh>
      {/* above-door wall panel, room side */}
      <AcousticPanel pos={[4.27, 2.71, 3.05]} size={[0.05, 0.86, 1.32]} />
      {/* EXIT sign (room side, above door) */}
      <mesh position={[4.235, 2.44, 3.05]} rotation-y={-Math.PI / 2}>
        <planeGeometry args={[0.96, 0.31]} />
        <meshStandardMaterial
          map={exitTexture()}
          emissive="#2bff85"
          emissiveMap={exitTexture()}
          emissiveIntensity={1.7}
          color="#001a0c"
        />
      </mesh>
      <Glow pos={[4.18, 2.44, 3.05]} scale={1.0} color="#37ff8a" opacity={0.22} />

      {/* open door leaf, swung into hallway against the south wall */}
      <group position={[4.4, 0, 3.56]} rotation-y={-1.72}>
        <mesh position={[0, 1.04, -0.55]} castShadow>
          <boxGeometry args={[0.055, 2.08, 1.06]} />
          <meshStandardMaterial map={doorWood} roughness={0.5} />
        </mesh>
        <mesh position={[0, 1.04, -0.55]}>
          <boxGeometry args={[0.06, 0.05, 1.06]} />
          <meshStandardMaterial color="#3c4046" roughness={0.3} metalness={0.85} />
        </mesh>
        {/* handle both faces */}
        <mesh position={[0.055, 1.02, -0.86]} rotation-x={Math.PI / 2}>
          <cylinderGeometry args={[0.02, 0.02, 0.1, 10]} />
          <meshStandardMaterial color="#9aa1ad" roughness={0.2} metalness={0.95} />
        </mesh>
        <mesh position={[-0.055, 1.02, -0.86]} rotation-x={Math.PI / 2}>
          <cylinderGeometry args={[0.02, 0.02, 0.1, 10]} />
          <meshStandardMaterial color="#9aa1ad" roughness={0.2} metalness={0.95} />
        </mesh>
      </group>

      {/* hallway shell */}
      <mesh position={[5.65, 1.15, 2.2]}>
        <planeGeometry args={[2.72, 2.3]} />
        <meshStandardMaterial color="#2b2119" roughness={0.92} />
      </mesh>
      <mesh position={[5.65, 1.15, 3.9]} rotation-y={Math.PI}>
        <planeGeometry args={[2.72, 2.3]} />
        <meshStandardMaterial color="#2b2119" roughness={0.92} />
      </mesh>
      <mesh position={[7.0, 1.15, 3.05]} rotation-y={-Math.PI / 2}>
        <planeGeometry args={[1.74, 2.3]} />
        <meshStandardMaterial color="#30251c" roughness={0.92} />
      </mesh>
      {/* hallway baseboards */}
      <Wood w={2.72} h={0.13} d={0.04} pos={[5.65, 0.065, 2.22]} />
      <Wood w={2.72} h={0.13} d={0.04} pos={[5.65, 0.065, 3.88]} />
      {/* hallway sconces */}
      <Sconce pos={[5.2, 1.7, 2.24]} rotY={0} />
      <Sconce pos={[6.25, 1.7, 2.24]} rotY={0} />
      {/* hallway end art */}
      <Poster url="posters/poster-orbit.jpg" pos={[6.96, 1.45, 3.05]} rotY={-Math.PI / 2} size={[0.55, 0.82]} />
      {/* small console table at hallway end */}
      <Wood w={0.85} h={0.05} d={0.3} pos={[6.72, 0.5, 3.05]} />
      <mesh position={[6.62, 0.25, 3.05]}>
        <boxGeometry args={[0.04, 0.5, 0.26]} />
        <meshStandardMaterial color="#241a12" roughness={0.6} />
      </mesh>
      <mesh position={[6.82, 0.25, 3.05]}>
        <boxGeometry args={[0.04, 0.5, 0.26]} />
        <meshStandardMaterial color="#241a12" roughness={0.6} />
      </mesh>
      <mesh position={[6.72, 0.62, 3.05]}>
        <cylinderGeometry args={[0.05, 0.04, 0.16, 12]} />
        <meshStandardMaterial color="#4a3520" roughness={0.5} />
      </mesh>
      <Glow pos={[6.55, 1.8, 3.05]} scale={1.6} opacity={0.1} />
    </group>
  );
}

/* ---------------- walls ---------------- */

function Walls() {
  const wallXs = [-3.4, -2.24, -1.08, 0.08, 1.24, 2.4];
  return (
    <group>
      {/* LEFT WALL */}
      <mesh position={[-W / 2, H / 2, 0]} rotation-y={Math.PI / 2}>
        <planeGeometry args={[D, H]} />
        <meshStandardMaterial color="#131216" roughness={0.95} />
      </mesh>
      {[-3.4, -2.24, -1.08, 0.08, 1.24, 2.4, 3.5].map((z) => (
        <AcousticPanel key={z} pos={[-4.26, 1.44, z]} size={[0.05, 2.6, 1.14]} />
      ))}
      <Wood w={0.06} h={0.15} d={D - 0.2} pos={[-4.26, 0.075, 0]} />
      <Wood w={0.055} h={0.05} d={D - 0.2} pos={[-4.25, 1.04, 0]} />
      <Metal w={0.055} h={0.07} d={D - 0.2} pos={[-4.25, 2.8, 0]} />
      <Sconce pos={[-4.22, 1.95, -1.0]} rotY={Math.PI / 2} />
      <Sconce pos={[-4.22, 1.95, 1.2]} rotY={Math.PI / 2} />
      <Poster url="posters/poster-neon.jpg" pos={[-4.21, 1.72, -1.55]} rotY={Math.PI / 2} />
      <Poster url="posters/poster-blade.jpg" pos={[-4.21, 1.72, 0.55]} rotY={Math.PI / 2} />

      {/* RIGHT WALL (door side) */}
      <mesh position={[W / 2, H / 2, 0]} rotation-y={-Math.PI / 2}>
        <planeGeometry args={[D, H]} />
        <meshStandardMaterial color="#131216" roughness={0.95} />
      </mesh>
      {[-3.4, -2.24, -1.08, 0.08, 1.24].map((z) => (
        <AcousticPanel key={z} pos={[4.26, 1.44, z]} size={[0.05, 2.6, 1.14]} />
      ))}
      <Wood w={0.06} h={0.15} d={D - 0.2} pos={[4.26, 0.075, 0]} />
      <Wood w={0.055} h={0.05} d={D - 0.2} pos={[4.25, 1.04, 0]} />
      <Metal w={0.055} h={0.07} d={D - 0.2} pos={[4.25, 2.8, 0]} />
      <Sconce pos={[4.22, 1.95, -0.6]} rotY={-Math.PI / 2} />
      {/* backlit poster lightbox */}
      <Poster url="posters/poster-blade.jpg" pos={[4.21, 1.72, 1.05]} rotY={-Math.PI / 2} lit />

      {/* BACK WALL */}
      <mesh position={[0, H / 2, D / 2]} rotation-y={Math.PI}>
        <planeGeometry args={[W, H]} />
        <meshStandardMaterial color="#131216" roughness={0.95} />
      </mesh>
      {wallXs.map((x) => (
        <AcousticPanel key={x} pos={[x, 1.44, 3.76]} size={[1.14, 2.6, 0.05]} />
      ))}
      <Wood w={W - 0.2} h={0.15} d={0.06} pos={[0, 0.075, 3.76]} />
      <Wood w={W - 0.2} h={0.05} d={0.055} pos={[0, 1.04, 3.75]} />
      <Metal w={W - 0.2} h={0.07} d={0.055} pos={[0, 2.8, 3.75]} />
      {/* neon brand sign */}
      <mesh position={[0, 2.5, 3.765]} rotation-y={Math.PI}>
        <planeGeometry args={[1.58, 0.31]} />
        <meshStandardMaterial
          map={neonTexture()}
          transparent
          emissive="#ffb36b"
          emissiveMap={neonTexture()}
          emissiveIntensity={1.35}
          color="#1a0f06"
        />
      </mesh>
      <Glow pos={[0, 2.5, 3.7]} scale={2.6} opacity={0.16} />

      {/* FRONT WALL around recess */}
      <mesh position={[-3.2, H / 2, -D / 2 + 0.01]}>
        <planeGeometry args={[2.2, H]} />
        <meshStandardMaterial color="#131216" roughness={0.95} />
      </mesh>
      <mesh position={[3.2, H / 2, -D / 2 + 0.01]}>
        <planeGeometry args={[2.2, H]} />
        <meshStandardMaterial color="#131216" roughness={0.95} />
      </mesh>
      <mesh position={[0, H / 2, -D / 2 + 0.01]}>
        <planeGeometry args={[4.3, H]} />
        <meshStandardMaterial color="#0d0c0f" roughness={0.95} />
      </mesh>
      {[-3.9, -2.85].map((x) => (
        <AcousticPanel key={`l${x}`} pos={[x, 1.44, -3.76]} size={[1.14, 2.6, 0.05]} />
      ))}
      {[2.85, 3.9].map((x) => (
        <AcousticPanel key={`r${x}`} pos={[x, 1.44, -3.76]} size={[1.14, 2.6, 0.05]} />
      ))}
      <AcousticPanel pos={[0, 2.95, -3.76]} size={[4.2, 0.42, 0.05]} />
      <Wood w={W - 0.2} h={0.15} d={0.06} pos={[0, 0.075, -3.76]} />

      {/* velvet curtains flanking the screen */}
      {[-2.38, 2.38].map((x) => (
        <group key={x}>
          <mesh position={[x, 1.56, -3.62]} castShadow>
            <boxGeometry args={[0.8, 2.92, 0.15]} />
            <meshStandardMaterial map={velvetTexture()} roughness={0.98} />
          </mesh>
        </group>
      ))}
      <mesh position={[0, 3.04, -3.6]} rotation-z={Math.PI / 2}>
        <cylinderGeometry args={[0.035, 0.035, 6.2, 12]} />
        <meshStandardMaterial color="#232326" roughness={0.35} metalness={0.8} />
      </mesh>
      {[-3.1, 3.1].map((x) => (
        <mesh key={x} position={[x, 3.04, -3.6]} rotation-z={Math.PI / 2}>
          <sphereGeometry args={[0.06, 10, 10]} />
          <meshStandardMaterial color="#232326" roughness={0.35} metalness={0.8} />
        </mesh>
      ))}

      {/* plants */}
      <Plant pos={[-3.85, 0, -3.28]} s={1.15} />
      <Plant pos={[3.85, 0, 1.6]} s={1} />
    </group>
  );
}

/* ---------------- export ---------------- */

export function CinemaShell() {
  return (
    <group>
      <Floor />
      <Ceiling />
      <CoveLight />
      <Walls />
      <DoorAndHallway />
    </group>
  );
}
