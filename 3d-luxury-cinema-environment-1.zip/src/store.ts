import { create } from "zustand";
import type * as THREE from "three";

export type Page = "home" | "room";

export interface Member {
  uid: string;
  name: string;
  joinedAt: number;
}

export interface ChatMsg {
  key: string;
  name: string;
  text: string;
  ts: number;
}

export interface ReactionMsg {
  key: string;
  name: string;
  kind: string;
  ts: number;
}

export interface MediaState {
  type: "movie" | "anime" | "youtube";
  title: string;
  serverId: string;
  url: string;
  ytId?: string;
  syncAt: number;
}

export interface PromptInfo {
  kind: "sit" | "stand";
  seatId: number;
}

interface Store {
  page: Page;
  setPage: (p: Page) => void;
  name: string;
  setName: (n: string) => void;
  roomId: string | null;
  hostUid: string | null;
  media: MediaState | null;
  members: Member[];
  messages: ChatMsg[];
  reactions: ReactionMsg[];
  setRoomState: (p: {
    roomId: string | null;
    hostUid: string | null;
    media: MediaState | null;
  }) => void;
  setMembers: (m: Member[]) => void;
  setMessages: (m: ChatMsg[]) => void;
  setReactions: (r: ReactionMsg[]) => void;
  countdownEnd: number | null;
  playing: boolean;
  setCountdownEnd: (n: number | null) => void;
  setPlaying: (b: boolean) => void;
  seated: number | null;
  sitMode: boolean;
  sit: (seatId: number) => void;
  stand: () => void;
  prompt: PromptInfo | null;
  setPrompt: (p: PromptInfo | null) => void;
  toast: string | null;
  showToast: (s: string) => void;
  clearToast: () => void;
  pickerOpen: boolean;
  setPickerOpen: (b: boolean) => void;
  chatOpen: boolean;
  setChatOpen: (b: boolean) => void;
}

const storedName = typeof localStorage !== "undefined" ? localStorage.getItem("aetho_name") ?? "" : "";

export const useStore = create<Store>()((set) => ({
  page: "home",
  setPage: (p) => set({ page: p }),
  name: storedName,
  setName: (n) => set({ name: n }),
  roomId: null,
  hostUid: null,
  media: null,
  members: [],
  messages: [],
  reactions: [],
  setRoomState: (p) => set({ roomId: p.roomId, hostUid: p.hostUid, media: p.media }),
  setMembers: (m) => set({ members: m }),
  setMessages: (m) => set({ messages: m }),
  setReactions: (r) => set({ reactions: r }),
  countdownEnd: null,
  playing: false,
  setCountdownEnd: (n) => set({ countdownEnd: n }),
  setPlaying: (b) => set({ playing: b }),
  seated: null,
  sitMode: false,
  sit: (seatId) => set({ seated: seatId, sitMode: true, prompt: null }),
  stand: () => set({ seated: null, sitMode: false }),
  prompt: null,
  setPrompt: (p) => set({ prompt: p }),
  toast: null,
  showToast: (s) => set({ toast: s }),
  clearToast: () => set({ toast: null }),
  pickerOpen: false,
  setPickerOpen: (b) => set({ pickerOpen: b }),
  chatOpen: false,
  setChatOpen: (b) => set({ chatOpen: b }),
}));

/* Shared mutable objects for the 3D layer — no React re-renders */
export const input = { x: 0, y: 0 };
export const shared3d: { camera: THREE.Camera | null } = { camera: null };
