import {
  ref,
  set,
  get,
  push,
  update,
  remove,
  onValue,
  onDisconnect,
  query,
  limitToLast,
} from "firebase/database";
import { db } from "./firebase";
import { useStore } from "../store";
import type { MediaState, ChatMsg, ReactionMsg, Member } from "../store";

/* ------------------------------------------------------------------ */
/* Identity                                                            */
/* ------------------------------------------------------------------ */
function randId(): string {
  return (
    Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10)
  );
}

export function getIdentity(): { uid: string; name: string } {
  let uid = localStorage.getItem("aetho_uid");
  if (!uid) {
    uid = randId();
    localStorage.setItem("aetho_uid", uid);
  }
  const name = localStorage.getItem("aetho_name") ?? "";
  return { uid, name };
}

export function saveName(name: string) {
  localStorage.setItem("aetho_name", name);
  useStore.getState().setName(name);
}

/* ------------------------------------------------------------------ */
/* Server clock offset (so countdown syncs across all clients)         */
/* ------------------------------------------------------------------ */
let offsetMs = 0;

export async function syncTime(): Promise<void> {
  try {
    const snap = await get(ref(db, ".info/serverTimeOffset"));
    offsetMs = snap.val() ?? 0;
  } catch {
    offsetMs = 0;
  }
}

export function nowServer(): number {
  return Date.now() + offsetMs;
}

/* ------------------------------------------------------------------ */
/* Streaming server list (edit patterns here to fit your upstreams)    */
/* ------------------------------------------------------------------ */
export interface ServerDef {
  id: string;
  name: string;
  tag: string;
  build: (title: string, tmdb?: string) => string;
}

const q = (s: string) => encodeURIComponent(s);

export const MOVIE_SERVERS: ServerDef[] = [
  { id: "nxsha", name: "Nxsha", tag: "HD + Subtitles", build: (t) => `https://nxsha.space/embed?query=${q(t)}` },
  { id: "zxcstream", name: "ZxcStream", tag: "Fast", build: (t) => `https://zxcstream.xyz/embed?query=${q(t)}` },
  { id: "bingr", name: "Bingr", tag: "4K", build: (t) => `https://bingr.one/embed?query=${q(t)}` },
  {
    id: "vidlink",
    name: "Vidlink",
    tag: "Multi-language",
    build: (t, tmdb) =>
      tmdb && /^\d+$/.test(tmdb.trim())
        ? `https://vidlink.pro/movie/${tmdb.trim()}`
        : `https://vidlink.pro/embed?query=${q(t)}`,
  },
  { id: "vidnest", name: "Vidnest", tag: "Backup", build: (t) => `https://vidnest.fun/embed?query=${q(t)}` },
];

export const ANIME_SERVERS: ServerDef[] = [
  { id: "megaplay", name: "MegaPlay", tag: "Primary", build: (t) => `https://megaplay.buzz/embed?query=${q(t)}` },
  { id: "animo", name: "4Animo ReCloud", tag: "HD-1 / HD-2", build: (t) => `https://cdn.4animo.xyz/embed?query=${q(t)}` },
  { id: "zoko", name: "ZokoAnime", tag: "Alt", build: (t) => `https://zokoanime.video/embed?query=${q(t)}` },
];

const VIDEO_SERVERS: ServerDef[] = [
  { id: "x", name: "YouTube (full sync)", tag: "Best sync", build: () => "" },
];

export function parseYouTubeId(url: string): string | null {
  const m = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/
  );
  return m ? m[1] : null;
}

/* ------------------------------------------------------------------ */
/* Room lifecycle                                                      */
/* ------------------------------------------------------------------ */
const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function genCode(): string {
  let c = "";
  for (let i = 0; i < 5; i++) c += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
  return c;
}

let roomRef: string | null = null;
const unsubs: Array<() => void> = [];
let heartbeat: ReturnType<typeof setInterval> | null = null;

function attachPresence(code: string, name: string) {
  const { uid } = getIdentity();
  const mRef = ref(db, `rooms/${code}/members/${uid}`);
  set(mRef, { name, joinedAt: nowServer(), lastSeen: nowServer() }).catch(() => {});
  try {
    onDisconnect(mRef).remove();
  } catch {
    /* offline — ignore */
  }
  if (heartbeat) clearInterval(heartbeat);
  heartbeat = setInterval(() => {
    update(mRef, { lastSeen: nowServer() }).catch(() => {});
  }, 15000);
}

export async function createRoom(name: string): Promise<string> {
  const { uid } = getIdentity();
  for (let i = 0; i < 10; i++) {
    const code = genCode();
    const snap = await get(ref(db, `rooms/${code}`));
    if (!snap.exists()) {
      await set(ref(db, `rooms/${code}`), {
        hostUid: uid,
        createdAt: nowServer(),
        media: null,
      });
      attachPresence(code, name);
      return code;
    }
  }
  throw new Error("Could not allocate a room code");
}

export async function joinRoom(code: string, name: string): Promise<boolean> {
  const c = code.trim().toUpperCase();
  const snap = await get(ref(db, `rooms/${c}`));
  if (!snap.exists()) return false;
  attachPresence(c, name);
  return true;
}

export function leaveRoom() {
  const { uid } = getIdentity();
  if (roomRef) {
    remove(ref(db, `rooms/${roomRef}/members/${uid}`)).catch(() => {});
  }
  unsubs.forEach((u) => u());
  unsubs.length = 0;
  if (heartbeat) clearInterval(heartbeat);
  heartbeat = null;
  roomRef = null;
  useStore.getState().setRoomState({ roomId: null, hostUid: null, media: null });
  useStore.getState().setMembers([]);
  useStore.getState().setMessages([]);
  useStore.getState().setReactions([]);
  useStore.getState().setCountdownEnd(null);
  useStore.getState().setPlaying(false);
}

export function subscribeRoom(code: string) {
  roomRef = code;
  const store = () => useStore.getState();

  unsubs.push(
    onValue(
      ref(db, `rooms/${code}`),
      (snap) => {
        const d = snap.val();
        if (!d) return;
        const members: Record<string, { name: string; joinedAt: number }> = d.members ?? {};
        let hostUid: string | null = d.hostUid ?? null;
        if (hostUid && !members[hostUid]) {
          const first = Object.keys(members).sort(
            (a, b) => (members[a].joinedAt ?? 0) - (members[b].joinedAt ?? 0)
          )[0];
          if (first) {
            hostUid = first;
            set(ref(db, `rooms/${code}/hostUid`), first).catch(() => {});
          } else {
            hostUid = null;
          }
        }
        store().setRoomState({ roomId: code, hostUid, media: d.media ?? null });
      },
      (err) => console.warn("room sub", err)
    )
  );

  unsubs.push(
    onValue(ref(db, `rooms/${code}/members`), (snap) => {
      const m = snap.val() ?? {};
      const list: Member[] = Object.entries(m as Record<string, Member>).map(([uid, v]) => ({
        uid,
        name: v?.name ?? "Guest",
        joinedAt: v?.joinedAt ?? 0,
      }));
      list.sort((a, b) => a.joinedAt - b.joinedAt);
      store().setMembers(list);
    })
  );

  unsubs.push(
    onValue(query(ref(db, `rooms/${code}/messages`), limitToLast(60)), (snap) => {
      const m = snap.val() ?? {};
      const list: ChatMsg[] = Object.entries(m as Record<string, ChatMsg>).map(([key, v]) => ({
        key,
        name: v?.name ?? "?",
        text: v?.text ?? "",
        ts: v?.ts ?? 0,
      }));
      store().setMessages(list);
    })
  );

  unsubs.push(
    onValue(query(ref(db, `rooms/${code}/reactions`), limitToLast(14)), (snap) => {
      const m = snap.val() ?? {};
      const list: ReactionMsg[] = Object.entries(m as Record<string, ReactionMsg>).map(([key, v]) => ({
        key,
        name: v?.name ?? "?",
        kind: v?.kind ?? "❤️",
        ts: v?.ts ?? 0,
      }));
      store().setReactions(list);
    })
  );
}

/* ------------------------------------------------------------------ */
/* Chat / reactions / media                                           */
/* ------------------------------------------------------------------ */
export function sendChat(text: string) {
  if (!roomRef || !text.trim()) return;
  const { name } = getIdentity();
  push(ref(db, `rooms/${roomRef}/messages`), {
    name,
    text: text.trim(),
    ts: nowServer(),
  }).catch(() => {});
}

export function sendReaction(kind: string) {
  if (!roomRef) return;
  const { name } = getIdentity();
  push(ref(db, `rooms/${roomRef}/reactions`), { name, kind, ts: nowServer() }).catch(() => {});
}

export const COUNTDOWN_SECONDS = 8;

export function hostChooseMedia(input: {
  type: "movie" | "anime" | "youtube";
  title: string;
  serverId: string;
  url: string;
  ytId?: string;
}) {
  if (!roomRef) return;
  const media: MediaState = {
    type: input.type,
    title: input.title,
    serverId: input.serverId,
    url: input.url,
    ytId: input.ytId,
    syncAt: nowServer() + COUNTDOWN_SECONDS * 1000,
  };
  set(ref(db, `rooms/${roomRef}/media`), media).catch(() => {});
}

export function hostStopMedia() {
  if (!roomRef) return;
  set(ref(db, `rooms/${roomRef}/media`), null).catch(() => {});
}

export function inviteLink(code: string): string {
  return `${location.origin}${location.pathname}?room=${code}`;
}

export { VIDEO_SERVERS };
