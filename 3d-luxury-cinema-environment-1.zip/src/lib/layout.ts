import * as THREE from "three";

/* ------------------------------------------------------------------ */
/* Room layout — compact private cinema dimensions                     */
/* ------------------------------------------------------------------ */
export const ROOM = { W: 8.6, D: 7.6, H: 3.12 };
export const PLATFORM = { h: 0.42, x0: -2.8, x1: 2.8, z0: 0.3, z1: 3.8 };
export const SCREEN = { w: 3.6, h: 2.03, bottomY: 0.62, z: -4.09, wallZ: -3.8 };

export interface SeatDef {
  id: number;
  x: number;
  z: number;
  row: number;
  platformH: number;
}

function buildSeats(): SeatDef[] {
  const seats: SeatDef[] = [];
  const xs = [-2, -1, 0, 1, 2];
  xs.forEach((x, i) => seats.push({ id: i + 1, x, z: -0.9, row: 1, platformH: 0 }));
  xs.forEach((x, i) => seats.push({ id: i + 6, x, z: 1.4, row: 2, platformH: PLATFORM.h }));
  return seats;
}

export const SEATS: SeatDef[] = buildSeats();

export interface Box {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
}

const seatBoxes: Box[] = SEATS.map((s) => ({
  x0: s.x - 0.48,
  x1: s.x + 0.48,
  z0: s.z - 0.52,
  z1: s.z + 0.52,
}));

export const COLLIDERS: Box[] = [
  { x0: -4.6, x1: 4.6, z0: -4.4, z1: -3.64 }, // screen wall
  { x0: -4.6, x1: 4.6, z0: 3.72, z1: 4.4 }, // back wall
  { x0: -4.6, x1: -4.18, z0: -4.4, z1: 4.4 }, // left wall
  { x0: 4.18, x1: 4.6, z0: -4.4, z1: 2.55 }, // right wall, before door
  { x0: 4.18, x1: 4.6, z0: 3.55, z1: 4.4 }, // right wall, after door
  { x0: 4.3, x1: 7.3, z0: 1.9, z1: 2.2 }, // hallway north wall
  { x0: 4.3, x1: 7.3, z0: 3.9, z1: 4.2 }, // hallway south wall
  { x0: 6.9, x1: 7.3, z0: 1.9, z1: 4.2 }, // hallway end wall
  { x0: 4.36, x1: 5.5, z0: 3.72, z1: 3.95 }, // open door panel (against south wall)
  { x0: -1.95, x1: 1.95, z0: -3.82, z1: -3.3 }, // media console
  { x0: -2.9, x1: -1.95, z0: -3.85, z1: -3.45 }, // left curtain + tower speaker
  { x0: 1.95, x1: 2.9, z0: -3.85, z1: -3.45 }, // right curtain + tower speaker
  { x0: -3.3, x1: -2.72, z0: -3.78, z1: -3.26 }, // subwoofer
  { x0: -4.2, x1: -3.6, z0: -3.62, z1: -3.0 }, // plant front-left
  { x0: 3.55, x1: 4.18, z0: 1.28, z1: 1.92 }, // plant near door
  ...seatBoxes,
];

/* Ground height: hallway, side steps, raised platform, floor */
export function groundHeightAt(x: number, z: number): number {
  if (x > 4.35 && z > 2.18 && z < 3.92) return 0;
  if (z >= PLATFORM.z0 && z <= PLATFORM.z1) {
    if (x >= 3.1 && x < 3.4) return 0.14;
    if (x >= 2.8 && x < 3.1) return 0.28;
    if (x > -3.4 && x <= -3.1) return 0.14;
    if (x > -3.1 && x <= -2.8) return 0.28;
    if (x >= PLATFORM.x0 && x <= PLATFORM.x1) return PLATFORM.h;
  }
  return 0;
}

export function hitAny(x: number, z: number, half = 0.21): boolean {
  for (const b of COLLIDERS) {
    if (x + half > b.x0 && x - half < b.x1 && z + half > b.z0 && z - half < b.z1) return true;
  }
  return false;
}

const MAX_STEP = 0.32;

export function attemptMove(
  px: number,
  pz: number,
  dx: number,
  dz: number,
  groundY: number
): { x: number; z: number } {
  let x = px;
  let z = pz;
  const nx = px + dx;
  if (!hitAny(nx, pz) && groundHeightAt(nx, pz) - groundY <= MAX_STEP) x = nx;
  const nz = z + dz;
  if (!hitAny(x, nz) && groundHeightAt(x, nz) - groundY <= MAX_STEP) z = nz;
  return { x, z };
}

/* Screen quad corners for the DOM video overlay (TL, TR, BR, BL) */
export const SCREEN_QUAD: THREE.Vector3[] = [
  new THREE.Vector3(-SCREEN.w / 2, SCREEN.bottomY + SCREEN.h, SCREEN.z),
  new THREE.Vector3(SCREEN.w / 2, SCREEN.bottomY + SCREEN.h, SCREEN.z),
  new THREE.Vector3(SCREEN.w / 2, SCREEN.bottomY, SCREEN.z),
  new THREE.Vector3(-SCREEN.w / 2, SCREEN.bottomY, SCREEN.z),
];

export function interactPoint(seat: SeatDef): THREE.Vector3 {
  return new THREE.Vector3(seat.x, seat.platformH, seat.z - 1.12);
}

export function sitPose(seat: SeatDef): { pos: THREE.Vector3; yaw: number } {
  return { pos: new THREE.Vector3(seat.x, seat.platformH + 0.34, seat.z + 0.06), yaw: Math.PI };
}

export function standSpot(seat: SeatDef): THREE.Vector3 {
  return new THREE.Vector3(seat.x, seat.platformH, seat.z - 0.84);
}

export function seatCam(seat: SeatDef): { pos: THREE.Vector3; look: THREE.Vector3 } {
  return {
    pos: new THREE.Vector3(
      seat.x * 0.55,
      seat.platformH + 1.62,
      Math.min(seat.z + 2.75, 3.55)
    ),
    look: new THREE.Vector3(0, 1.52, -3.4),
  };
}
