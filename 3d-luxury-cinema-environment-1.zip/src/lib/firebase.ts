import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCHXQR-bxsJzUPV3rv5qsJxtsx4OZfqHBk",
  authDomain: "party-6e846.firebaseapp.com",
  databaseURL: "https://party-6e846-default-rtdb.firebaseio.com",
  projectId: "party-6e846",
  storageBucket: "party-6e846.firebasestorage.app",
  messagingSenderId: "73498570577",
  appId: "1:73498570577:web:e38adb014978a4d13b2d70",
};

export const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
