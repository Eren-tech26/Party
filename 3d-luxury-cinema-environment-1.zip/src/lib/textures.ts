import * as THREE from "three";

/* Procedural canvas textures — dark, warm, premium */

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function canvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!];
}

const cache = new Map<string, THREE.CanvasTexture>();

function tex(key: string, c: HTMLCanvasElement, repeat?: [number, number]): THREE.CanvasTexture {
  const hit = cache.get(key);
  if (hit) return hit;
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  if (repeat) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat[0], repeat[1]);
  }
  cache.set(key, t);
  return t;
}

/* Dark premium carpet */
export function carpetTexture(rx = 9, ry = 8): THREE.CanvasTexture {
  const key = `carpet${rx}x${ry}`;
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(256, 256);
  const rnd = mulberry32(7);
  g.fillStyle = "#17181d";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 5200; i++) {
    const x = rnd() * 256;
    const y = rnd() * 256;
    const s = rnd() * 1.6 + 0.4;
    g.fillStyle =
      rnd() > 0.72
        ? `rgba(74,76,86,${0.1 + rnd() * 0.18})`
        : `rgba(7,7,10,${0.14 + rnd() * 0.24})`;
    g.fillRect(x, y, s, s);
  }
  g.globalAlpha = 0.06;
  for (let y = 0; y < 256; y += 4) {
    g.fillStyle = y % 8 === 0 ? "#2a2c33" : "#101116";
    g.fillRect(0, y, 256, 1);
  }
  g.globalAlpha = 1;
  return tex(key, c, [rx, ry]);
}

/* Dark walnut wood */
export function woodTexture(rx = 2, ry = 1): THREE.CanvasTexture {
  const key = `wood${rx}x${ry}`;
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(256, 256);
  const rnd = mulberry32(21);
  g.fillStyle = "#33231a";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 90; i++) {
    const y = rnd() * 256;
    const amp = 2 + rnd() * 5;
    const dark = rnd() > 0.5;
    g.strokeStyle = dark ? `rgba(16,9,5,${0.1 + rnd() * 0.22})` : `rgba(96,68,44,${0.07 + rnd() * 0.14})`;
    g.lineWidth = 0.6 + rnd() * 1.8;
    g.beginPath();
    g.moveTo(0, y);
    for (let x = 0; x <= 256; x += 16) {
      g.quadraticCurveTo(x + 8, y + Math.sin(x * 0.05 + i) * amp, x + 16, y);
    }
    g.stroke();
  }
  return tex(key, c, [rx, ry]);
}

/* Charcoal acoustic wall panel with vertical slats */
export function panelTexture(): THREE.CanvasTexture {
  const key = "panel";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(256, 256);
  g.fillStyle = "#1d1e24";
  g.fillRect(0, 0, 256, 256);
  for (let x = 0; x < 256; x += 32) {
    const grad = g.createLinearGradient(x, 0, x + 25, 0);
    grad.addColorStop(0, "#17181d");
    grad.addColorStop(0.5, "#23242b");
    grad.addColorStop(1, "#17181d");
    g.fillStyle = grad;
    g.fillRect(x, 0, 25, 256);
  }
  g.fillStyle = "#0c0d10";
  for (let x = 0; x < 256; x += 32) g.fillRect(x + 25, 0, 3, 256);
  g.fillStyle = "rgba(255,255,255,0.045)";
  for (let x = 0; x < 256; x += 32) g.fillRect(x + 25, 0, 1, 256);
  return tex(key, c);
}

/* Deep burgundy velvet (curtains) */
export function velvetTexture(): THREE.CanvasTexture {
  const key = "velvet";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(256, 256);
  const rnd = mulberry32(33);
  g.fillStyle = "#2a1017";
  g.fillRect(0, 0, 256, 256);
  for (let x = 0; x < 256; x++) {
    const s = Math.sin(x * 0.32) * 0.5 + 0.5;
    g.fillStyle = `rgba(0,0,0,${s * 0.32})`;
    g.fillRect(x, 0, 1, 256);
    g.fillStyle = `rgba(255,110,140,${(1 - s) * 0.05})`;
    g.fillRect(x, 0, 1, 256);
  }
  for (let i = 0; i < 2400; i++) {
    const x = rnd() * 256;
    const y = rnd() * 256;
    g.fillStyle = rnd() > 0.5 ? "rgba(70,20,32,0.35)" : "rgba(10,4,6,0.35)";
    g.fillRect(x, y, 1.4, 1.4);
  }
  return tex(key, c);
}

/* Burgundy lounge fabric with speckle */
export function fabricTexture(): THREE.CanvasTexture {
  const key = "fabric";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(256, 256);
  const rnd = mulberry32(55);
  g.fillStyle = "#5c1524";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 6000; i++) {
    const x = rnd() * 256;
    const y = rnd() * 256;
    const l = rnd();
    g.fillStyle =
      l > 0.75
        ? `rgba(140,52,74,${0.1 + rnd() * 0.2})`
        : l > 0.4
          ? `rgba(66,13,29,${0.12 + rnd() * 0.2})`
          : `rgba(20,4,9,${0.1 + rnd() * 0.16})`;
    g.fillRect(x, y, 1.2 + rnd(), 1.2 + rnd());
  }
  const grad = g.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, "rgba(255,255,255,0.045)");
  grad.addColorStop(0.5, "rgba(0,0,0,0)");
  grad.addColorStop(1, "rgba(0,0,0,0.25)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 256);
  return tex(key, c);
}

/* Radial glow sprite (fake bloom for LEDs) */
export function glowTexture(): THREE.CanvasTexture {
  const key = "glow";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(128, 128);
  const grad = g.createRadialGradient(64, 64, 2, 64, 64, 64);
  grad.addColorStop(0, "rgba(255,255,255,0.95)");
  grad.addColorStop(0.35, "rgba(255,255,255,0.32)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  return tex(key, c);
}

/* Illuminated EXIT sign */
export function exitTexture(): THREE.CanvasTexture {
  const key = "exit";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(512, 168);
  g.fillStyle = "#060a07";
  g.fillRect(0, 0, 512, 168);
  g.strokeStyle = "rgba(80,255,150,0.35)";
  g.lineWidth = 4;
  g.strokeRect(6, 6, 500, 156);
  g.font = "700 86px Arial, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.shadowColor = "#2bff85";
  g.shadowBlur = 30;
  g.fillStyle = "#4dffa0";
  g.fillText("EXIT", 300, 88);
  g.font = "900 70px Arial, sans-serif";
  g.fillText("◀", 92, 88);
  g.shadowBlur = 10;
  g.fillStyle = "#e9fff2";
  g.fillText("EXIT", 300, 88);
  g.shadowBlur = 25;
  g.fillStyle = "#b9ffd6";
  g.fillText("◀", 92, 88);
  return tex(key, c);
}

/* Idle "off" screen with faint AethoFlix wordmark */
export function screenIdleTexture(): THREE.CanvasTexture {
  const key = "screenidle";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(1024, 576);
  const grad = g.createLinearGradient(0, 0, 0, 576);
  grad.addColorStop(0, "#0d1017");
  grad.addColorStop(0.55, "#07090e");
  grad.addColorStop(1, "#05060a");
  g.fillStyle = grad;
  g.fillRect(0, 0, 1024, 576);
  const vig = g.createRadialGradient(512, 288, 140, 512, 288, 640);
  vig.addColorStop(0, "rgba(0,0,0,0)");
  vig.addColorStop(1, "rgba(0,0,0,0.62)");
  g.fillStyle = vig;
  g.fillRect(0, 0, 1024, 576);
  g.fillStyle = "rgba(255,255,255,0.02)";
  for (let y = 0; y < 576; y += 6) g.fillRect(0, y, 1024, 1);
  g.textAlign = "center";
  g.shadowColor = "rgba(120,180,255,0.35)";
  g.shadowBlur = 26;
  g.fillStyle = "rgba(160,172,192,0.85)";
  g.font = "600 54px Outfit, Arial, sans-serif";
  const word = "AETHOFLIX";
  let tw = 0;
  for (const ch of word) tw += g.measureText(ch).width + 10;
  let x = 512 - tw / 2;
  g.font = "600 54px Outfit, Arial, sans-serif";
  for (const ch of word) {
    g.fillText(ch, x + g.measureText(ch).width / 2, 300);
    x += g.measureText(ch).width + 10;
  }
  g.shadowBlur = 16;
  g.fillStyle = "rgba(255,179,107,0.55)";
  g.fillRect(512 - 90, 330, 180, 3);
  g.shadowBlur = 0;
  g.fillStyle = "rgba(140,150,168,0.5)";
  g.font = "500 26px Inter, Arial, sans-serif";
  g.fillText("PRIVATE SCREENING ROOM", 512, 396);
  return tex(key, c);
}

/* Warm neon AETHOFLIX sign */
export function neonTexture(): THREE.CanvasTexture {
  const key = "neon";
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(1024, 200);
  g.clearRect(0, 0, 1024, 200);
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = "700 104px Outfit, Arial, sans-serif";
  g.shadowColor = "#ff8a3d";
  g.shadowBlur = 34;
  g.fillStyle = "#ffb36b";
  g.fillText("AETHOFLIX", 512, 96);
  g.shadowBlur = 12;
  g.fillStyle = "#ffe9cf";
  g.fillText("AETHOFLIX", 512, 96);
  return tex(key, c);
}

/* Floating player name tag */
export function tagTexture(name: string): THREE.CanvasTexture {
  const key = `tag${name}`;
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(256, 96);
  g.clearRect(0, 0, 256, 96);
  g.font = "600 40px Outfit, Arial, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  const short = name.length > 14 ? name.slice(0, 13) + "…" : name;
  g.shadowColor = "rgba(0,0,0,0.9)";
  g.shadowBlur = 10;
  g.fillStyle = "rgba(255,255,255,0.92)";
  g.fillText(short, 128, 48);
  return tex(key, c);
}

/* Seat number badge */
export function seatNumberTexture(n: number): THREE.CanvasTexture {
  const key = `seatn${n}`;
  if (cache.has(key)) return cache.get(key)!;
  const [c, g] = canvas(128, 64);
  g.clearRect(0, 0, 128, 64);
  const r = 10;
  g.beginPath();
  g.roundRect(6, 6, 116, 52, r);
  g.fillStyle = "rgba(8,8,10,0.85)";
  g.fill();
  g.strokeStyle = "rgba(255,179,107,0.45)";
  g.lineWidth = 2.5;
  g.stroke();
  g.font = "700 32px Outfit, Arial, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillStyle = "#f3d9b8";
  g.fillText(String(n), 64, 34);
  return tex(key, c);
}
