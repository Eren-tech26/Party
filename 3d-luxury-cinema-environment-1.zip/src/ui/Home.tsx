import { useEffect, useState } from "react";
import { createRoom, joinRoom, subscribeRoom, saveName } from "../lib/room";
import { useStore } from "../store";

export function Home() {
  const name = useStore((s) => s.name);
  const [tab, setTab] = useState<"create" | "join">("join");
  const [nameInput, setNameInput] = useState(name);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const r = new URLSearchParams(location.search).get("room");
    if (r) {
      setTab("join");
      setCode(r.toUpperCase());
    }
  }, []);

  const ensureName = (): string | null => {
    const n = nameInput.trim();
    if (!n) {
      setError("Enter your name first.");
      return null;
    }
    saveName(n);
    setError("");
    return n;
  };

  const doCreate = async () => {
    const n = ensureName();
    if (!n || busy) return;
    setBusy(true);
    try {
      const c = await createRoom(n);
      subscribeRoom(c);
      useStore.getState().setPage("room");
    } catch {
      setError("Could not create the room. Try again.");
      setBusy(false);
    }
  };

  const doJoin = async () => {
    const n = ensureName();
    if (!n || busy) return;
    if (code.trim().length < 4) {
      setError("Enter the room code from your host.");
      return;
    }
    setBusy(true);
    try {
      const ok = await joinRoom(code, n);
      if (!ok) {
        setError("No room found with that code.");
        setBusy(false);
        return;
      }
      subscribeRoom(code.trim().toUpperCase());
      useStore.getState().setPage("room");
    } catch {
      setError("Could not join. Check your connection.");
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center overflow-y-auto bg-black px-4 py-8"
      style={{
        background:
          "radial-gradient(1000px 500px at 50% 108%, rgba(255,140,50,0.13), transparent 60%), radial-gradient(700px 380px at 12% -8%, rgba(120,140,190,0.07), transparent 60%), #000",
      }}
    >
      <div className="w-full max-w-md anim-fade-up">
        {/* brand */}
        <div className="mb-8 text-center">
          <div className="mb-3 flex items-center justify-center gap-2">
            <div className="h-9 w-9 rounded-2xl border border-white/15 bg-gradient-to-br from-amber-200/80 to-amber-500/60 p-2 shadow-[0_0_30px_rgba(255,170,80,0.35)]">
              <svg viewBox="0 0 24 24" className="h-full w-full text-black" fill="currentColor">
                <path d="M5 3.9c0-1.2 1.3-2 2.4-1.4l13.6 7.6c1.1.6 1.1 2.2 0 2.8L7.4 20.5c-1.1.6-2.4-.2-2.4-1.4V3.9z" />
              </svg>
            </div>
            <h1 className="font-display text-4xl font-bold tracking-[0.08em] text-silver">
              AETHOFLIX
            </h1>
          </div>
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-400/10 px-3 py-1 text-[11px] font-semibold tracking-[0.25em] text-amber-glow">
            ◆ WATCH PARTY CINEMA ◆
          </div>
          <p className="mt-4 text-sm leading-relaxed text-white/45">
            A private 3D cinema with{" "}
            <span className="text-white/75">10 recliner seats</span>. Sit down, watch together,
            chat &amp; react live — goofy but luxurious.
          </p>
        </div>

        {/* card */}
        <div className="glass rounded-3xl p-5">
          {/* name */}
          <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-widest text-white/40">
            Your name
          </label>
          <input
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            maxLength={16}
            placeholder="e.g. Aetho"
            className="mb-4 w-full rounded-2xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
          />

          {/* tabs */}
          <div className="mb-4 grid grid-cols-2 gap-1 rounded-2xl border border-white/8 bg-black/40 p-1">
            {(
              [
                ["join", "Join with code"],
                ["create", "Create a room"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => {
                  setTab(id);
                  setError("");
                }}
                className={`btn-glass rounded-xl px-3 py-2.5 text-xs font-semibold tracking-wide ${
                  tab === id
                    ? "bg-gradient-to-b from-white/16 to-white/6 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.15)]"
                    : "text-white/40 hover:text-white/70"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === "join" ? (
            <>
              <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-widest text-white/40">
                Room code
              </label>
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5))}
                placeholder="e.g. K7XQM"
                className="mb-4 w-full rounded-2xl border border-white/10 bg-black/40 px-4 py-3 text-center font-display text-2xl font-bold tracking-[0.5em] text-silver outline-none placeholder:text-white/15 focus:border-amber-300/40"
              />
              <button
                onClick={doJoin}
                disabled={busy}
                className="btn-glass anim-pulse-glow w-full rounded-2xl bg-gradient-to-b from-amber-200 via-amber-300 to-amber-500 px-4 py-3.5 font-display text-sm font-bold tracking-widest text-black"
              >
                {busy ? "ENTERING…" : "ENTER CINEMA →"}
              </button>
            </>
          ) : (
            <button
              onClick={doCreate}
              disabled={busy}
              className="btn-glass anim-pulse-glow w-full rounded-2xl bg-gradient-to-b from-amber-200 via-amber-300 to-amber-500 px-4 py-3.5 font-display text-sm font-bold tracking-widest text-black"
            >
              {busy ? "OPENING THEATRE…" : "OPEN A PRIVATE CINEMA →"}
            </button>
          )}

          {error && (
            <div className="mt-3 rounded-xl border border-red-400/25 bg-red-500/10 px-3 py-2 text-xs text-red-300">
              {error}
            </div>
          )}
        </div>

        {/* feature chips */}
        <div className="mt-5 flex flex-wrap justify-center gap-2 text-[11px] text-white/40">
          {[
            "🛋️ 10 recliners · 2 tiers",
            "🔁 Synced 8s countdown",
            "💬 Live chat + reactions",
            "🎬 Movie / TV / Anime servers",
            "📱 Mobile joystick",
          ].map((f) => (
            <span key={f} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5">
              {f}
            </span>
          ))}
        </div>
        <p className="mt-4 text-center text-[11px] leading-relaxed text-white/25">
          Share the room code — friends join the same 3D room and watch the shared screen together.
          <br />
          Everyone is a little blocky person. That's the charm.
        </p>
      </div>
    </div>
  );
}
