import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { SCREEN_QUAD } from "../lib/layout";
import { nowServer } from "../lib/room";
import { shared3d, useStore } from "../store";

const OW = 1280;
const OH = 720;

/**
 * Solves a 2D homography mapping src points -> dst points.
 * Returns the 3x3 matrix (row-major, h22 = 1) ready for CSS matrix3d.
 */
function solveHomography(src: number[][], dst: number[][]): number[] {
  const A: number[][] = [];
  const b: number[] = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = src[i];
    const [u, v] = dst[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]);
    b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]);
    b.push(v);
  }
  const n = 8;
  for (let col = 0; col < n; col++) {
    let piv = col;
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(A[r][col]) > Math.abs(A[piv][col])) piv = r;
    }
    [A[col], A[piv]] = [A[piv], A[col]];
    [b[col], b[piv]] = [b[piv], b[col]];
    const d = A[col][col] || 1e-9;
    for (let r = col + 1; r < n; r++) {
      const f = A[r][col] / d;
      if (f === 0) continue;
      for (let c = col; c < n; c++) A[r][c] -= f * A[col][c];
      b[r] -= f * b[col];
    }
  }
  const h = new Array<number>(9).fill(0);
  for (let r = n - 1; r >= 0; r--) {
    let s = b[r];
    for (let c = r + 1; c < n; c++) s -= A[r][c] * h[c];
    h[r] = s / (A[r][r] || 1e-9);
  }
  h[8] = 1;
  return h;
}

/**
 * DOM video overlay that is perspective-mapped onto the 3D screen quad.
 * The shared stream (server embed or YouTube) appears on the cinema screen
 * and follows it from any camera angle.
 */
export function ScreenOverlay() {
  const playing = useStore((s) => s.playing);
  const media = useStore((s) => s.media);
  const divRef = useRef<HTMLDivElement>(null);
  const srcC = useMemo(
    () => [
      [0, 0],
      [OW, 0],
      [OW, OH],
      [0, OH],
    ],
    []
  );

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    const v = new THREE.Vector3();
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const el = divRef.current;
      const camera = shared3d.camera;
      if (!el || !camera) return;
      const pts: number[][] = [];
      let ok = true;
      for (const p of SCREEN_QUAD) {
        v.copy(p).applyMatrix4(camera.matrixWorldInverse);
        if (v.z > -0.12) {
          ok = false;
          break;
        }
        v.copy(p).project(camera);
        pts.push([
          ((v.x + 1) / 2) * window.innerWidth,
          ((1 - (v.y + 1)) / 2) * window.innerHeight,
        ]);
      }
      if (!ok) {
        el.style.opacity = "0";
        el.style.pointerEvents = "none";
        return;
      }
      let minX = Infinity;
      let maxX = -Infinity;
      let minY = Infinity;
      let maxY = -Infinity;
      for (const q of pts) {
        minX = Math.min(minX, q[0]);
        maxX = Math.max(maxX, q[0]);
        minY = Math.min(minY, q[1]);
        maxY = Math.max(maxY, q[1]);
      }
      if (
        maxX < -80 ||
        minX > window.innerWidth + 80 ||
        maxY < -80 ||
        minY > window.innerHeight + 80
      ) {
        el.style.opacity = "0";
        el.style.pointerEvents = "none";
        return;
      }
      const h = solveHomography(srcC, pts);
      el.style.transform = `matrix3d(${h[0]},${h[3]},0,${h[6]},${h[1]},${h[4]},0,${h[7]},0,0,1,0,${h[2]},${h[5]},0,1)`;
      el.style.opacity = "1";
      el.style.pointerEvents = "auto";
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [playing, media, srcC]);

  if (!playing || !media) return null;

  const src =
    media.type === "youtube" && media.ytId
      ? `https://www.youtube-nocookie.com/embed/${media.ytId}?autoplay=1&rel=0&modestbranding=1&start=${Math.max(
          0,
          Math.floor((nowServer() - media.syncAt) / 1000)
        )}`
      : media.url;

  return (
    <div className="pointer-events-none fixed inset-0 z-[12]">
      <div
        ref={divRef}
        className="pointer-events-auto"
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: OW,
          height: OH,
          transformOrigin: "0 0",
          opacity: 0,
          willChange: "transform",
        }}
      >
        <iframe
          src={src}
          title="AethoFlix shared screen"
          className="h-full w-full"
          style={{ border: 0, background: "#000" }}
          allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
          allowFullScreen
        />
      </div>
    </div>
  );
}
