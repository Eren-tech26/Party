import { useRef } from "react";
import { input } from "../store";

/**
 * Virtual joystick — smooth analog movement for touch & mouse.
 * Writes normalized (-1..1) values into the shared `input` object.
 */
export function Joystick() {
  const baseRef = useRef<HTMLDivElement>(null);
  const thumbRef = useRef<HTMLDivElement>(null);
  const activeId = useRef<number | null>(null);
  const R = 46;

  const setThumb = (dx: number, dy: number) => {
    if (thumbRef.current) {
      thumbRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
    }
  };

  const handle = (e: React.PointerEvent) => {
    const base = baseRef.current;
    if (!base) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const len = Math.hypot(dx, dy);
    if (len > R) {
      dx = (dx / len) * R;
      dy = (dy / len) * R;
    }
    setThumb(dx, dy);
    input.x = dx / R;
    input.y = -dy / R;
  };

  const start = (e: React.PointerEvent) => {
    activeId.current = e.pointerId;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    handle(e);
  };

  const move = (e: React.PointerEvent) => {
    if (activeId.current !== e.pointerId) return;
    handle(e);
  };

  const end = (e: React.PointerEvent) => {
    if (activeId.current !== e.pointerId) return;
    activeId.current = null;
    input.x = 0;
    input.y = 0;
    setThumb(0, 0);
  };

  return (
    <div
      ref={baseRef}
      onPointerDown={start}
      onPointerMove={move}
      onPointerUp={end}
      onPointerCancel={end}
      className="fixed bottom-6 left-5 z-40 h-32 w-32 touch-none select-none rounded-full glass cursor-pointer"
      style={{
        boxShadow:
          "0 10px 40px rgba(0,0,0,.6), inset 0 1px 0 rgba(255,255,255,.09), inset 0 0 30px rgba(255,179,107,.05)",
      }}
    >
      <div className="absolute inset-0 rounded-full border border-white/5" />
      {/* direction hints */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-white/20 text-[9px] font-semibold tracking-widest">
        MOVE
      </div>
      <div
        ref={thumbRef}
        className="pointer-events-none absolute left-1/2 top-1/2 h-14 w-14 -ml-7 -mt-7 rounded-full"
        style={{
          background:
            "radial-gradient(circle at 32% 30%, rgba(255,255,255,.35), rgba(255,255,255,.06) 45%, rgba(0,0,0,.25))",
          border: "1px solid rgba(255,255,255,.25)",
          boxShadow: "0 6px 22px rgba(0,0,0,.55), 0 0 18px rgba(255,179,107,.15)",
        }}
      />
    </div>
  );
}
