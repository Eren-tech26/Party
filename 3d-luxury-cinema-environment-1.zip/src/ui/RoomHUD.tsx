import { useEffect, useRef, useState } from "react";
import {
  ANIME_SERVERS,
  COUNTDOWN_SECONDS,
  MOVIE_SERVERS,
  hostChooseMedia,
  getIdentity,
  hostStopMedia,
  inviteLink,
  leaveRoom,
  nowServer,
  parseYouTubeId,
  sendChat,
  sendReaction,
} from "../lib/room";
import { useStore } from "../store";

const REACTION_EMOJI: Record<string, string> = {
  kiss: "💋",
  hug: "🤗",
  slap: "🖐️",
  kick: "🦵",
};

function serverName(id: string): string {
  return (
    MOVIE_SERVERS.find((s) => s.id === id)?.name ??
    ANIME_SERVERS.find((s) => s.id === id)?.name ??
    (id === "youtube" ? "YouTube" : id)
  );
}

/* ================= Top bar ================= */

function TopBar() {
  const roomId = useStore((s) => s.roomId);
  const members = useStore((s) => s.members);
  const chatOpen = useStore((s) => s.chatOpen);
  const showToast = useStore((s) => s.showToast);

  const copy = async () => {
    if (!roomId) return;
    try {
      await navigator.clipboard.writeText(inviteLink(roomId));
      showToast("Invite link copied ✨");
    } catch {
      showToast(`Share this code: ${roomId}`);
    }
  };

  const leave = () => {
    leaveRoom();
    useStore.getState().setPage("home");
  };

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-2 p-3">
      <div className="pointer-events-auto flex items-center gap-2">
        <div className="glass flex items-center gap-2 rounded-2xl px-3 py-2">
          <span className="font-display text-sm font-bold tracking-[0.15em] text-silver">
            AETHOFLIX
          </span>
          <span className="hidden text-[10px] font-semibold tracking-widest text-amber-300/70 sm:inline">
            PRIVATE SCREEN
          </span>
        </div>
        <button
          onClick={copy}
          className="btn-glass glass flex items-center gap-2 rounded-2xl px-3 py-2 text-xs font-semibold"
          title="Copy invite link"
        >
          <span className="text-amber-glow font-display tracking-[0.3em]">{roomId ?? "—"}</span>
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 text-white/50" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="9" y="9" width="11" height="11" rx="2" />
            <path d="M5 15V5a2 2 0 0 1 2-2h10" />
          </svg>
        </button>
      </div>
      <div className="pointer-events-auto flex items-center gap-2">
        <div className="glass rounded-2xl px-3 py-2 text-xs font-semibold text-white/70">
          👥 {members.length}
        </div>
        <button
          onClick={() => useStore.getState().setChatOpen(!chatOpen)}
          className={`btn-glass glass rounded-2xl px-3 py-2 text-xs font-semibold ${
            chatOpen ? "text-amber-glow" : "text-white/70"
          }`}
        >
          💬 Chat
        </button>
        <button
          onClick={leave}
          className="btn-glass glass rounded-2xl px-3 py-2 text-xs font-semibold text-white/60 hover:text-red-300"
        >
          Exit
        </button>
      </div>
    </div>
  );
}

/* ================= Chat + members ================= */

function SidePanel() {
  const chatOpen = useStore((s) => s.chatOpen);
  const [text, setText] = useState("");
  const listRef = useRef<HTMLDivElement>(null);
  const messages = useStore((s) => s.messages);
  const members = useStore((s) => s.members);
  const hostUid = useStore((s) => s.hostUid);
  const uid = getIdentity().uid;

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages, chatOpen]);

  if (!chatOpen) return null;

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    sendChat(text);
    setText("");
  };

  return (
    <div className="absolute bottom-24 left-3 right-3 top-20 z-30 sm:bottom-5 sm:left-auto sm:right-3 sm:top-16 sm:w-[330px]">
      <div className="glass-deep flex h-full flex-col rounded-3xl overflow-hidden anim-pop">
        {/* members */}
        <div className="border-b border-white/8 px-4 py-3">
          <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.22em] text-white/35">
            In the room · {members.length}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {members.map((m) => (
              <span
                key={m.uid}
                className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium ${
                  m.uid === uid
                    ? "border-amber-300/35 bg-amber-400/10 text-amber-100"
                    : "border-white/10 bg-white/5 text-white/70"
                }`}
              >
                <span className="flex h-4.5 w-4.5 items-center justify-center rounded-full bg-gradient-to-br from-slate-400 to-slate-600 text-[8px] font-bold text-black">
                  {m.name.slice(0, 1).toUpperCase()}
                </span>
                {m.name}
                {m.uid === hostUid && <span className="text-[10px]">👑</span>}
                {m.uid === uid && <span className="text-[9px] text-white/40">(you)</span>}
              </span>
            ))}
          </div>
        </div>
        {/* messages */}
        <div ref={listRef} className="chat-scroll flex-1 space-y-2 overflow-y-auto px-4 py-3">
          {messages.length === 0 && (
            <div className="py-6 text-center text-xs text-white/30">
              No messages yet — say hi 👋
            </div>
          )}
          {messages.map((m) => (
            <div key={m.key} className="anim-fade-up">
              <div className="flex items-baseline gap-2">
                <span className="text-[11px] font-bold text-amber-200/80">{m.name}</span>
                <span className="text-[9px] text-white/25">
                  {new Date(m.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
              <div className="break-words text-[13px] leading-snug text-white/85">{m.text}</div>
            </div>
          ))}
        </div>
        {/* input */}
        <form onSubmit={send} className="flex items-center gap-2 border-t border-white/8 p-3">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            maxLength={240}
            placeholder="Message the room…"
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-[13px] text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
          />
          <button
            type="submit"
            className="btn-glass rounded-xl bg-gradient-to-b from-amber-200 to-amber-500 px-4 py-2.5 text-[13px] font-bold text-black"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}

/* ================= Media bar ================= */

function MediaBar() {
  const media = useStore((s) => s.media);
  const hostUid = useStore((s) => s.hostUid);
  const uid = getIdentity().uid;
  const playing = useStore((s) => s.playing);
  const setPickerOpen = useStore((s) => s.setPickerOpen);
  const isHost = hostUid === uid;

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-2 z-30 flex justify-center px-3">
      <div className="glass pointer-events-auto flex max-w-full items-center gap-2.5 rounded-2xl px-4 py-2.5">
        {media ? (
          <>
            <span className="text-base">{media.type === "youtube" ? "▶️" : "🎬"}</span>
            <div className="min-w-0">
              <div className="truncate text-[13px] font-semibold text-white/90">
                {media.title}
              </div>
              <div className="text-[10px] text-white/40">
                {serverName(media.serverId)} · {playing ? "Now screening" : "Starting…"}
              </div>
            </div>
            {isHost && (
              <>
                <button
                  onClick={() => setPickerOpen(true)}
                  className="btn-glass rounded-xl border border-white/12 bg-white/8 px-3 py-1.5 text-[11px] font-semibold text-white/75"
                >
                  Change
                </button>
                <button
                  onClick={hostStopMedia}
                  className="btn-glass rounded-xl border border-red-400/25 bg-red-500/10 px-3 py-1.5 text-[11px] font-semibold text-red-300"
                >
                  Stop
                </button>
              </>
            )}
          </>
        ) : isHost ? (
          <button
            onClick={() => setPickerOpen(true)}
            className="btn-glass anim-pulse-glow flex items-center gap-2 rounded-xl bg-gradient-to-b from-amber-200 to-amber-500 px-4 py-2 text-[13px] font-bold text-black"
          >
            🎬 Pick a movie for everyone
          </button>
        ) : (
          <div className="text-[12px] text-white/45">
            ⏳ Waiting for the host to pick something…
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= Countdown ================= */

function CountdownOverlay() {
  const cd = useStore((s) => s.countdownEnd);
  const media = useStore((s) => s.media);
  const playing = useStore((s) => s.playing);
  const [rem, setRem] = useState(0);

  useEffect(() => {
    if (cd == null) return;
    const tick = () => {
      const r = (cd - nowServer()) / 1000;
      setRem(Math.max(0, Math.ceil(r)));
      if (r <= 0) {
        useStore.getState().setPlaying(true);
        useStore.getState().setCountdownEnd(null);
      }
    };
    tick();
    const iv = setInterval(tick, 120);
    return () => clearInterval(iv);
  }, [cd, media]);

  if (cd == null || playing) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-40 flex flex-col items-center justify-center bg-black/55 backdrop-blur-[3px]">
      <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.4em] text-amber-300/80">
        {media ? media.title : "Starting"} — synced for everyone
      </div>
      <div
        key={rem}
        className="anim-count glass-deep flex h-36 w-36 items-center justify-center rounded-full font-display text-6xl font-bold text-silver"
        style={{ boxShadow: "0 0 70px rgba(255,170,80,.28), inset 0 0 30px rgba(255,179,107,.08)" }}
      >
        {rem}
      </div>
      <div className="mt-4 text-xs text-white/50">Get comfy… it starts together 🔒</div>
    </div>
  );
}

/* ================= Reactions ================= */

function ReactionDock() {
  return (
    <div className="pointer-events-none absolute bottom-6 right-4 z-30 flex flex-col gap-2 sm:flex-row">
      {(
        [
          ["kiss", "💋", "Kiss"],
          ["hug", "🤗", "Hug"],
          ["slap", "🖐️", "Slap"],
          ["kick", "🦵", "Kick"],
        ] as const
      ).map(([id, emoji, label]) => (
        <button
          key={id}
          onClick={() => sendReaction(id)}
          className="btn-glass glass pointer-events-auto flex h-12 w-16 flex-col items-center justify-center rounded-2xl hover:border-amber-300/30"
          title={label}
        >
          <span className="text-xl">{emoji}</span>
          <span className="text-[8px] font-semibold uppercase tracking-widest text-white/40">
            {label}
          </span>
        </button>
      ))}
    </div>
  );
}

function FloatingReactions() {
  const reactions = useStore((s) => s.reactions);
  const [floats, setFloats] = useState<Array<{ key: string; emoji: string; x: number }>>([]);
  const seen = useRef<Set<string>>(new Set());

  useEffect(() => {
    for (const r of reactions) {
      if (seen.current.has(r.key)) continue;
      seen.current.add(r.key);
      setFloats((p) => [
        ...p.slice(-10),
        { key: r.key, emoji: REACTION_EMOJI[r.kind] ?? r.kind, x: 15 + Math.random() * 70 },
      ]);
      setTimeout(() => {
        setFloats((p) => p.filter((f) => f.key !== r.key));
      }, 2700);
    }
  }, [reactions]);

  return (
    <div className="pointer-events-none fixed inset-0 z-[35] overflow-hidden">
      {floats.map((f) => (
        <span
          key={f.key}
          className="anim-float-up absolute bottom-[30%] text-5xl drop-shadow-[0_4px_18px_rgba(255,170,80,0.4)]"
          style={{ left: `${f.x}%` }}
        >
          {f.emoji}
        </span>
      ))}
    </div>
  );
}

/* ================= Sit / Stand ================= */

function SitStandButton() {
  const prompt = useStore((s) => s.prompt);
  if (!prompt) return null;
  return (
    <div className="pointer-events-none absolute bottom-16 left-1/2 z-30 -translate-x-1/2">
      <button
        onClick={() => {
          const st = useStore.getState();
          if (st.sitMode) st.stand();
          else if (prompt.kind === "sit") st.sit(prompt.seatId);
        }}
        className={`btn-glass anim-pop pointer-events-auto rounded-2xl px-6 py-3 font-display text-sm font-bold tracking-widest ${
          prompt.kind === "sit"
            ? "anim-pulse-glow bg-gradient-to-b from-amber-200 via-amber-300 to-amber-500 text-black"
            : "glass text-white/85"
        }`}
      >
        {prompt.kind === "sit" ? "🪑 SIT DOWN" : "⬆️ STAND UP"}
        <span className="ml-2 hidden text-[9px] font-semibold tracking-widest opacity-60 sm:inline">
          [E]
        </span>
      </button>
    </div>
  );
}

/* ================= Toast ================= */

function Toast() {
  const toast = useStore((s) => s.toast);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => useStore.getState().clearToast(), 2600);
    return () => clearTimeout(t);
  }, [toast]);
  if (!toast) return null;
  return (
    <div className="anim-pop pointer-events-none fixed left-1/2 top-16 z-50 -translate-x-1/2">
      <div className="glass-deep rounded-2xl px-5 py-2.5 text-[13px] font-medium text-white/90">
        {toast}
      </div>
    </div>
  );
}

/* ================= Server picker (host) ================= */

function PickerModal() {
  const open = useStore((s) => s.pickerOpen);
  const [tab, setTab] = useState<"movie" | "anime" | "youtube">("movie");
  const [title, setTitle] = useState("");
  const [tmdb, setTmdb] = useState("");
  const [server, setServer] = useState("nxsha");
  const [yt, setYt] = useState("");
  const [custom, setCustom] = useState("");
  const [err, setErr] = useState("");

  if (!open) return null;
  const list = tab === "anime" ? ANIME_SERVERS : MOVIE_SERVERS;
  const isYt = tab === "youtube";

  const start = () => {
    setErr("");
    if (isYt) {
      const id = parseYouTubeId(yt.trim());
      if (!id) {
        setErr("That doesn't look like a YouTube link.");
        return;
      }
      hostChooseMedia({
        type: "youtube",
        title: title.trim() || "YouTube Video",
        serverId: "youtube",
        url: yt.trim(),
        ytId: id,
      });
    } else {
      if (!title.trim()) {
        setErr("Type a movie / show / anime title.");
        return;
      }
      const def = list.find((s) => s.id === server) ?? list[0];
      const url = custom.trim() || def.build(title.trim(), tmdb.trim() || undefined);
      hostChooseMedia({
        type: tab,
        title: title.trim(),
        serverId: def.id,
        url,
      });
    }
    useStore.getState().setPickerOpen(false);
    useStore.getState().showToast("Countdown started for everyone 🎬");
  };

  return (
    <div className="fixed inset-0 z-[45] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="glass-deep w-full max-w-lg max-h-[88vh] overflow-y-auto chat-scroll rounded-3xl p-5 anim-pop">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-silver">Choose what we watch</h2>
          <button
            onClick={() => useStore.getState().setPickerOpen(false)}
            className="btn-glass rounded-xl border border-white/10 px-3 py-1.5 text-xs text-white/60"
          >
            ✕
          </button>
        </div>

        <div className="mb-4 grid grid-cols-3 gap-1 rounded-2xl border border-white/8 bg-black/40 p-1">
          {(
            [
              ["movie", "Movie / TV"],
              ["anime", "Anime"],
              ["youtube", "YouTube"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => {
                setTab(id);
                setErr("");
                if (id !== "youtube") setServer(id === "anime" ? "megaplay" : "nxsha");
              }}
              className={`btn-glass rounded-xl px-2 py-2 text-[11px] font-bold tracking-wide ${
                tab === id
                  ? "bg-gradient-to-b from-white/16 to-white/6 text-white"
                  : "text-white/40"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {!isYt && (
          <>
            <label className="mb-1 block text-[10px] font-bold uppercase tracking-widest text-white/35">
              Title
            </label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={tab === "anime" ? "e.g. Frieren — S1E1" : "e.g. Interstellar"}
              className="mb-3 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
            />
            <label className="mb-1 block text-[10px] font-bold uppercase tracking-widest text-white/35">
              TMDB ID <span className="text-white/25">(optional — better match)</span>
            </label>
            <input
              value={tmdb}
              onChange={(e) => setTmdb(e.target.value.replace(/[^0-9]/g, ""))}
              placeholder="e.g. 157336"
              className="mb-3 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
            />

            <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-white/35">
              Streaming server
            </label>
            <div className="mb-3 grid grid-cols-2 gap-2">
              {list.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setServer(s.id)}
                  className={`btn-glass rounded-xl border px-3 py-2.5 text-left ${
                    server === s.id
                      ? "border-amber-300/50 bg-amber-400/10"
                      : "border-white/10 bg-white/4"
                  }`}
                >
                  <div className="text-[12px] font-bold text-white/90">
                    {s.name}
                    {i === 0 && <span className="ml-1 text-[9px] text-amber-300/80">★</span>}
                  </div>
                  <div className="text-[10px] text-white/40">{s.tag}</div>
                </button>
              ))}
            </div>

            <label className="mb-1 block text-[10px] font-bold uppercase tracking-widest text-white/35">
              Custom embed URL <span className="text-white/25">(optional override)</span>
            </label>
            <input
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="https://…"
              className="mb-3 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
            />
          </>
        )}

        {isYt && (
          <label className="mb-1 block text-[10px] font-bold uppercase tracking-widest text-white/35">
            YouTube link <span className="text-amber-300/70">— best sync of all</span>
          </label>
        )}
        {isYt && (
          <input
            value={yt}
            onChange={(e) => setYt(e.target.value)}
            placeholder="https://youtube.com/watch?v=…"
            className="mb-3 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
          />
        )}
        {isYt && (
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Label (optional)"
            className="mb-3 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-sm text-white outline-none placeholder:text-white/25 focus:border-amber-300/40"
          />
        )}

        {err && (
          <div className="mb-3 rounded-xl border border-red-400/25 bg-red-500/10 px-3 py-2 text-xs text-red-300">
            {err}
          </div>
        )}

        <button
          onClick={start}
          className="btn-glass anim-pulse-glow w-full rounded-2xl bg-gradient-to-b from-amber-200 via-amber-300 to-amber-500 px-4 py-3.5 font-display text-sm font-bold tracking-widest text-black"
        >
          ▶ START {COUNTDOWN_SECONDS}s COUNTDOWN FOR EVERYONE
        </button>
        <p className="mt-3 text-center text-[10px] leading-relaxed text-white/30">
          Playback starts together via a synced countdown — embed players can't be frame-synced,
          so everyone begins at the same moment. YouTube keeps the start time synced too.
        </p>
      </div>
    </div>
  );
}

/* ================= HUD root ================= */

export function RoomHUD() {
  const media = useStore((s) => s.media);

  /* react to media changes (works for joiners too) */
  useEffect(() => {
    const m = useStore.getState().media;
    if (!m) {
      useStore.getState().setPlaying(false);
      useStore.getState().setCountdownEnd(null);
      return;
    }
    if (m.syncAt <= nowServer()) {
      useStore.getState().setPlaying(true);
      useStore.getState().setCountdownEnd(null);
    } else {
      useStore.getState().setPlaying(false);
      useStore.getState().setCountdownEnd(m.syncAt);
    }
  }, [media]);

  return (
    <>
      <TopBar />
      <SidePanel />
      <MediaBar />
      <ReactionDock />
      <SitStandButton />
      <CountdownOverlay />
      <FloatingReactions />
      <Toast />
      <PickerModal />
      {/* touch hint */}
      <div className="pointer-events-none absolute left-1/2 top-2 z-20 -translate-x-1/2 rounded-full bg-black/30 px-3 py-1 text-[10px] text-white/30 backdrop-blur-sm">
        WASD / joystick to walk · walk to a seat &amp; tap to sit
      </div>
    </>
  );
}
