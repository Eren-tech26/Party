import { useEffect } from "react";
import { Home } from "./ui/Home";
import { RoomHUD } from "./ui/RoomHUD";
import { Joystick } from "./ui/Joystick";
import { ScreenOverlay } from "./ui/ScreenOverlay";
import { CinemaSceneView } from "./three/Scene";
import { syncTime } from "./lib/room";
import { useStore } from "./store";

export default function App() {
  const page = useStore((s) => s.page);

  useEffect(() => {
    syncTime();
  }, []);

  if (page === "room") {
    return (
      <div className="fixed inset-0 bg-black overflow-hidden">
        <CinemaSceneView />
        <ScreenOverlay />
        <Joystick />
        <RoomHUD />
      </div>
    );
  }

  return <Home />;
}
